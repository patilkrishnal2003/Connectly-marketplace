// src/lib/paths.ts
import categoriesJson from "@/data/categories.json";
import coursesJson from "@/data/courses.json";
import type { Category, Course } from "@/types";

/* ----------------- Parse & type JSON ----------------- */
const categories = categoriesJson as Category[];
const courses = coursesJson as Course[];

/* ----------------- Utils ----------------- */
const toSlug = (s: string) =>
  s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)+/g, "");

/** Build a slug. Accepts a title string or a course object. */
export const courseSlugFrom = (
  input: string | { title: string; id?: string; slug?: string },
  fallbackId?: string
) => {
  if (typeof input === "string") {
    return fallbackId ? `${toSlug(input)}-${fallbackId}` : toSlug(input);
  }
  if (input.slug) return input.slug;
  return input.id ? `${toSlug(input.title)}-${input.id}` : toSlug(input.title);
};

/* ----------------- Category lookups ----------------- */
export const getCategoryBySlug = (slug: string) =>
  categories.find((c) => c.slug === slug);

export const getCategoryById = (id: string) =>
  categories.find((c) => c.id === id);

export const categorySlugById = (id: string) =>
  getCategoryById(id)?.slug ?? id;

/* ----------------- URL builders ----------------- */
export const categoryPath = (categorySlug: string) => `/${categorySlug}`;
export const coursePath = (categorySlug: string, courseSlug: string) =>
  `/${categorySlug}/${courseSlug}`;

/* ----------------- Course normalization ----------------- */
/** UI-safe course: always has slug + duration (+ tag if badges exist) */
export type CourseVM = Course & {
  slug: string;
  duration: string;
  tag?: "Trending" | "Most Popular" | "Recommended" | "New Launch" | string;
};

export const normalizeCourse = (c: Course): CourseVM => ({
  ...c,
  slug: c.slug ?? courseSlugFrom(c),
  duration: c.duration ?? (c.hours ? `${c.hours} Hrs` : ""),
  tag: c.tag ?? (Array.isArray(c.badges) ? c.badges[0] : undefined),
});

/** Find by slug (supports derived slugs) and return a normalized CourseVM */
export const getCourseBySlug = (slug: string): CourseVM | undefined => {
  const raw = courses.find((c) => (c.slug ?? courseSlugFrom(c)) === slug);
  return raw ? normalizeCourse(raw) : undefined;
};
