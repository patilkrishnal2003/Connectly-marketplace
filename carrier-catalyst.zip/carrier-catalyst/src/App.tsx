// src/App.tsx
import { BrowserRouter, Routes, Route } from "react-router-dom";
import SiteLayout from "@/layout/SiteLayout";
import Home from "@/pages/Home";
import NotFound from "@/pages/NotFound";
import CategoryPage from "@/pages/CategoryPage";
import CourseDetail from "@/pages/CourseDetail"; // NEW

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<SiteLayout />}>
          {/* "/" */}
          <Route index element={<Home />} />

          {/* Phase 3: /{categorySlug}/{courseSlug} */}
          <Route path=":categorySlug/:courseSlug" element={<CourseDetail />} />

          {/* Phase 2: /{categorySlug} */}
          <Route path=":categorySlug" element={<CategoryPage />} />

          {/* Catch-all */}
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
