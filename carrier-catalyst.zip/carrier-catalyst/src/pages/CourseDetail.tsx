// src/pages/CourseDetail.tsx
import { Link, useParams } from "react-router-dom";
import categories from "@/data/categories.json";
import { categoryPath, categorySlugById, getCourseBySlug } from "@/lib/paths";
import CourseHero from "@/components/course/CourseHero";
import CourseSlider from "@/components/course/CourseSlider";
import CourseFaq from "@/components/course/CourseFaq";
import CourseInfoRail from "@/components/course/CourseInfoRail";
import CourseLearningPath from "@/components/course/CourseLearningPath";
import InfoRequestCard from "@/components/course/InfoRequestCard";
import CourseObjectives from "@/components/course/CourseObjectives";

type Cat = { id: string; name: string; slug: string };

export default function CourseDetail() {
  const { categorySlug = "", courseSlug = "" } = useParams();
  const course = getCourseBySlug(courseSlug); // normalized CourseVM

  if (!course) {
    return (
      <div className="mx-auto max-w-5xl px-4 py-16">
        <h1 className="text-2xl font-semibold">Course not found</h1>
        <p className="mt-3 text-gray-600">
          <Link to="/" className="text-sky-600 hover:underline">Go back home</Link>
        </p>
      </div>
    );
  }

  // ---------- Breadcrumb ----------
  const courseCatSlugs = course.categories.map(categorySlugById);
  const crumbCatSlug =
    courseCatSlugs.includes(categorySlug) ? categorySlug : courseCatSlugs[0];
  const crumbCatName =
    (categories as Cat[]).find((c) => c.slug === crumbCatSlug)?.name ?? crumbCatSlug;

  // ---------- Slider context ----------
  const contextCategoryId =
    course.categories.find((id) => categorySlug === categorySlugById(id)) ??
    course.categories[0];

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      {/* breadcrumb */}
      <nav className="text-sm text-gray-600">
        <Link to="/" className="hover:underline">Home</Link> /{" "}
        <Link to={categoryPath(crumbCatSlug)} className="hover:underline">{crumbCatName}</Link> /{" "}
        <span className="text-gray-800">{course.title}</span>
      </nav>

      {/* Hero */}
      <CourseHero course={course} />

      {/* Info rail */}
      <CourseInfoRail
        closesOn={course.applicationCloseOn}
        duration={course.durationLabel ?? course.duration ?? (course.hours ? `${course.hours} Hrs` : undefined)}
        format={course.learningFormat ?? course.modes?.join(", ")}
      />

      {/* Learning Objectives */}
      {course.objectives?.items?.length ? (
        <div className="mt-10">
          <CourseObjectives data={course.objectives} courseTitle={course.title} />
        </div>
      ) : null}

      {/* Learning Path + Info Request */}
      <div className="mt-10 grid gap-6 md:grid-cols-12">
        <div className="md:col-span-8">
          {course.learningPath?.modules?.length ? (
            <CourseLearningPath path={course.learningPath} />
          ) : null}
        </div>
        <div className="md:col-span-4">
          <InfoRequestCard courseTitle={course.title} />
        </div>
      </div>

      {/* FAQ */}
      {Array.isArray((course as any).faqs) && (course as any).faqs.length > 0 && (
        <div className="mt-10">
          <CourseFaq items={(course as any).faqs} />
        </div>
      )}

      {/* Explore more */}
      <CourseSlider
        contextCategoryId={contextCategoryId}
        excludeCourseId={course.id}
        excludeCourseSlug={course.slug}
        title="Explore more in this category"
        subtitle={`More ${crumbCatName} courses`}
      />
    </div>
  );
}
