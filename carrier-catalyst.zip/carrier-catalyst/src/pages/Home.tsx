import HeroSlider from "@/components/home/HeroSlider";
import CoursesGrid from "@/components/home/CoursesGrid";
import ScrollingDomains from "@/components/home/ScrollingDomains";
import TestimonialsSection from "@/components/home/TestimonialsSection";

export default function Home() {
  return (
    <>
      <HeroSlider />
      <div className="py-8">
        <CoursesGrid />
      </div>
      <ScrollingDomains />
      <TestimonialsSection />
    </>
  );
}
