// src/pages/CategoryPage.tsx
import { useMemo } from "react";
import { Link, useParams } from "react-router-dom";
import rawCourses from "@/data/courses.json";
import CategoryFaq from "@/components/category/categoryFaq";
import CategoryInsights from "@/components/category/CategoryInsights";

import {
  coursePath,
  getCategoryBySlug,
  categorySlugById,
  normalizeCourse,
  courseSlugFrom,
} from "@/lib/paths";
import type { Category, Course } from "@/types";
import type { CourseVM } from "@/lib/paths";

import CategoryHero from "@/components/category/CategoryHero";
import { CourseCard } from "@/components/home/CourseCard"; // <- adjust path if needed
import CategorySlider from "@/components/category/CategorySlider";


export default function CategoryPage() {
  const { categorySlug = "" } = useParams();

  const category: Category | undefined = useMemo(
    () => getCategoryBySlug(categorySlug),
    [categorySlug]
  );

  if (!category || category.id === "all") {
    return (
      <div className="mx-auto max-w-6xl px-4 py-16 text-center">
        <h1 className="text-2xl font-bold text-slate-900">Category not found</h1>
        <p className="mt-2 text-slate-600">
          Please check the URL or pick a category from the menu.
        </p>
      </div>
    );
  }

  // 1) Raw list for passing into <CourseCard />
  const rawList: Course[] = useMemo(
    () =>
      (rawCourses as Course[]).filter(
        (c) => Array.isArray(c.categories) && c.categories.includes(category.id)
      ),
    [category.id]
  );

  // 2) VM list if you need duration/tag in this page elsewhere
  const listVM: CourseVM[] = useMemo(
    () => rawList.map(normalizeCourse),
    [rawList]
  );

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      {/* breadcrumb */}
      <nav className="mb-6 text-sm text-gray-600">
        <Link to="/" className="hover:underline">Home</Link> /{" "}
        <span className="text-gray-800">{category.name}</span>
      </nav>

      {/* premium hero (fallback header is inside the component if hero missing) */}
      <CategoryHero category={category} count={listVM.length} />
      
    

      {/* grid */}
      {rawList.length === 0 ? (
        <div className="rounded-2xl border bg-white p-8 text-center text-slate-600">
          No courses yet in this category.
        </div>
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {rawList.map((course) => {
            const primaryCatId = course.categories[0];
            const catSlug = categorySlugById(primaryCatId);
            const slug = course.slug ?? courseSlugFrom(course.title, course.id);

            return (
              <Link
                key={course.id}
                to={coursePath(catSlug, slug)}
                className="block transition hover:-translate-y-0.5"
              >
                <CourseCard course={{ 
                  ...course, 
                  slug,
                  modes: course.modes || [],
                  enrolled: course.enrolled || 0,
                  hours: course.hours || 0,
                  priceInr: course.priceInr || 0
                }} />
              </Link>
            );
          })}
        </div>
      )}

      {/* FAQ section */}
      <CategoryFaq items={category.faqs || []}  />
      {/* Category Insights  */}
      {category.insights && <CategoryInsights data={category.insights} />}

      {/* On a Category page (exclude the current one) */}
      <CategorySlider
      title="Explore other categories"
      subtitle="Browse more domains you might be interested in"
      currentId={category.id}
    />
    </div>
  );
}
