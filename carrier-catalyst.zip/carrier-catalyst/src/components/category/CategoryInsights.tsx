import type { Category } from "@/types";
import {
  Wallet, Gem, Smartphone, Radio, Globe2, TrendingUp
} from "lucide-react";

type Insights = NonNullable<Category["insights"]>;

/** Map simple string keys from JSON to Lucide icons */
const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  wallet: Wallet,
  gem: Gem,
  smartphone: Smartphone,
  radio: Radio,
  globe: Globe2,
  growth: TrendingUp,
};

export default function CategoryInsights({ data }: { data: Insights }) {
  return (
    <section className="mx-auto max-w-6xl px-4 mt-12">
      <div className="rounded-3xl bg-slate-50 ring-1 ring-slate-200 p-6 md:p-10">
        <div className="grid gap-8 md:grid-cols-12">
          {/* Left column: text */}
          <div className="md:col-span-6 lg:col-span-5">
            {data.eyebrow && (
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-600">
                {data.eyebrow}
              </p>
            )}
            <h2 className="mt-2 text-2xl md:text-3xl font-black text-slate-900">
              {data.title}
            </h2>

            {Array.isArray(data.body) && data.body.length > 0 && (
              <div className="mt-4 space-y-4 text-[15px] leading-7 text-slate-700">
                {data.body.map((p, i) => (
                  <p key={i}>{p}</p>
                ))}
              </div>
            )}
          </div>

          {/* Right column: stat cards */}
          <div className="md:col-span-6 lg:col-span-7">
            <div className="grid gap-4 sm:grid-cols-2">
              {data.cards.map((c, i) => {
                const Icon = iconMap[c.icon ?? "globe"] ?? Globe2;
                return (
                  <div
                    key={i}
                    className="rounded-2xl bg-white p-5 ring-1 ring-slate-200 shadow-sm hover:shadow-md transition"
                  >
                    <div className="flex items-start gap-4">
                      <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 ring-1 ring-emerald-200">
                        <Icon className="h-5 w-5 text-emerald-600" />
                        <span className="absolute -right-1 -top-1 inline-block h-2.5 w-2.5 rounded-full bg-emerald-300" />
                      </div>
                      <div>
                        <div className="text-xl font-extrabold text-slate-900">
                          {c.value}
                        </div>
                        <p className="mt-1 text-sm text-slate-600">{c.caption}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
