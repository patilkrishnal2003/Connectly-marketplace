import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import cats from "@/data/categories.json";
import { categoryPath } from "@/lib/paths";
import type { Category } from "@/types";
import {
  KanbanSquare,
  ClipboardList,
  Brain,
  Cloud,
  Code2,
  Wrench,
  ShieldCheck,
  Circle,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";

/**
 * Premium Category Slider:
 * - hidden scrollbar (global .no-scrollbar css)
 * - edge fade (.mask-edge)
 * - auto-scroll (pauses on hover), arrows, snap
 * - click routes to /{categorySlug}
 */
export default function CategorySlider({
  title = "Explore other categories",
  subtitle = "Browse more domains you might be interested in",
  currentId,
  auto = true,
  speed = 0.35, // px per frame
}: {
  title?: string;
  subtitle?: string;
  currentId?: string;
  auto?: boolean;
  speed?: number;
}) {
  const raw = useMemo(
    () => (cats as Category[]).filter((c) => c.id !== "all"),
    []
  );
  const data = useMemo(
    () => raw.filter((c) => (currentId ? c.id !== currentId : true)),
    [raw, currentId]
  );

  // Duplicate list to enable seamless loop
  const slides = useMemo(() => [...data, ...data], [data]);

  const iconMap: Record<string, React.ElementType> = {
    agile: KanbanSquare,
    pm: ClipboardList,
    datasci: Brain,
    cloud: Cloud,
    web: Code2,
    devops: Wrench,
    itsec: ShieldCheck,
  };

  const trackRef = useRef<HTMLDivElement | null>(null);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    const el = trackRef.current;
    if (!el) return;
    // Start at middle of duplicated content
    el.scrollLeft = el.scrollWidth / 4;
  }, [slides.length]);

  // Auto-scroll
  useEffect(() => {
    if (!auto) return;
    const el = trackRef.current;
    if (!el) return;

    let raf = 0;
    const loop = () => {
      if (!paused) {
        el.scrollLeft += speed;
        const half = el.scrollWidth / 2;
        if (el.scrollLeft >= half + half / 2) el.scrollLeft -= half;
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [auto, paused, speed, slides.length]);

  const scrollByAmount = (dir: "left" | "right") => {
    const el = trackRef.current;
    if (!el) return;
    const amt = el.clientWidth * 0.8 * (dir === "left" ? -1 : 1);
    el.scrollBy({ left: amt, behavior: "smooth" });
  };

  if (data.length === 0) return null;

  return (
    <section
      className="relative mx-auto max-w-6xl py-10"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      {/* Header */}
      <div className="mb-5 text-center">
        <h2 className="text-xl font-bold text-slate-900">{title}</h2>
        <p className="mt-1 text-sm text-slate-600">{subtitle}</p>
      </div>

      {/* Track wrapper with edge mask + hidden scrollbar */}
      <div className="relative">
        {/* Arrows */}
        <button
          aria-label="Previous"
          onClick={() => scrollByAmount("left")}
          className="absolute left-3 top-1/2 z-20 -translate-y-1/2 rounded-full border border-slate-200 bg-white p-2 text-slate-700 shadow-sm transition hover:bg-slate-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <button
          aria-label="Next"
          onClick={() => scrollByAmount("right")}
          className="absolute right-3 top-1/2 z-20 -translate-y-1/2 rounded-full border border-slate-200 bg-white p-2 text-slate-700 shadow-sm transition hover:bg-slate-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400"
        >
          <ChevronRight className="h-5 w-5" />
        </button>

        <div className="mask-edge">
          <div
            ref={trackRef}
            className="no-scrollbar flex snap-x snap-mandatory gap-4 overflow-x-auto scroll-smooth px-1 py-2 touch-pan-x select-none"
          >
            {slides.map((c, i) => {
              const Icon = iconMap[c.id] ?? Circle;
              return (
                <Link key={`${c.id}-${i}`} to={categoryPath(c.slug)} className="snap-start">
                  <div className="group flex h-28 w-[240px] items-center justify-between rounded-2xl border border-slate-200 bg-white px-4 shadow-[0_6px_20px_rgba(2,6,23,0.06)] ring-1 ring-transparent transition hover:-translate-y-0.5 hover:border-sky-200 hover:ring-sky-100">
                    <div className="flex items-center gap-3">
                      <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-sky-50 text-sky-600 ring-1 ring-sky-100 transition group-hover:bg-sky-100">
                        <Icon className="h-5 w-5" />
                      </span>
                      <div className="text-[15px] font-semibold text-slate-900">
                        {c.name}
                      </div>
                    </div>
                    <ChevronRight className="h-5 w-5 shrink-0 text-slate-400 transition group-hover:text-sky-600" />
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
