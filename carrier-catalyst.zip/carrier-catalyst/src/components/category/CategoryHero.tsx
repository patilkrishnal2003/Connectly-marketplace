// components/category/CategoryHero.tsx
import { Link } from "react-router-dom";
import { CheckCircle2, ChevronRight } from "lucide-react";
import type { Category } from "@/types";
import { categoryPath } from "@/lib/paths";

type Props = {
  category: Category;
  count?: number;
};

export default function CategoryHero({ category, count }: Props) {
  const hero = category.hero;

  // Fallback if hero block is missing
  if (!hero) {
    return (
      <div className="mb-8 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-sky-600">
            Explore Programs
          </p>
          <h1 className="mt-1 text-2xl font-black text-slate-900">{category.name}</h1>
          {typeof count === "number" && (
            <p className="mt-1 text-sm text-slate-600">
              {count} course{count === 1 ? "" : "s"} found
            </p>
          )}
        </div>
        <Link
          to={categoryPath(category.slug)}
          className="rounded-full border px-3 py-1.5 text-sm text-slate-800 hover:bg-slate-50"
        >
          Explore all courses
        </Link>
      </div>
    );
  }

  return (
    <section
      className="
        relative mb-10 overflow-hidden
        bg-transparent  /* ← same as body, no card look */
        p-0 md:p-0
      "
    >
      {/* very soft ambient blobs (kept subtle) */}
      <div className="pointer-events-none absolute -left-24 -top-24 h-72 w-72 rounded-full bg-sky-200/20 blur-3xl" />
      <div className="pointer-events-none absolute -right-24 -bottom-24 h-80 w-80 rounded-full bg-indigo-200/15 blur-3xl" />

      <div className="relative grid items-center gap-8 md:grid-cols-2">
        {/* Visual */}
        <div className="order-2 md:order-1">
          {hero.image && (
            <img
              src={hero.image}
              alt=""
              className="h-72 w-full rounded-2xl object-cover md:h-[360px]"
              loading="lazy"
            />
          )}
        </div>

        {/* Copy */}
        <div className="order-1 md:order-2">
          {hero.label && (
            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
              {hero.label}
            </span>
          )}

          {hero.title && (
            <h1 className="mt-3 text-3xl font-black leading-tight text-slate-900 md:text-4xl">
              {hero.title}
            </h1>
          )}

          {hero.subtitle && (
            <p className="mt-3 text-[15px] leading-relaxed text-slate-600">
              {hero.subtitle}
            </p>
          )}

          {hero.bullets?.length ? (
            <ul className="mt-5 space-y-2 text-[15px] text-slate-700">
              {hero.bullets.map((b, i) => (
                <li key={i} className="flex items-start gap-2">
                  <CheckCircle2 className="mt-0.5 h-5 w-5 text-emerald-600" />
                  <span>{b}</span>
                </li>
              ))}
            </ul>
          ) : null}

          <div className="mt-6 flex flex-wrap gap-3">
            <Link
              to={categoryPath(category.slug)}
              className="inline-flex items-center gap-2 rounded-xl bg-sky-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-sky-700"
            >
              {hero.ctaExploreText ?? "Explore Courses"}
              <ChevronRight className="h-4 w-4" />
            </Link>

            {hero.ctaAdvisorText && (
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 rounded-xl border px-4 py-2.5 text-sm font-semibold text-slate-800 hover:bg-slate-50"
              >
                {hero.ctaAdvisorText}
              </Link>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
