import { useMemo, useState } from "react";
import rawCourses from "@/data/courses.json";
import rawCats from "@/data/categories.json";
import { CourseCard, type Course } from "./CourseCard";
import CategoryTabs, { type Category } from "./CategoryTabs";
import { ChevronLeft, Search } from "lucide-react";
import { Button } from "@/components/ui/button";

const DEFAULT_ROWS = 2;              // show 2 rows initially
const CARDS_PER_ROW = 3;             // 3 cards/row on desktop
const STEP = CARDS_PER_ROW * 2;      // load 2 rows per click (6 cards)

export default function CoursesGrid() {
  const categories = rawCats as Category[];
  const courses = rawCourses as Course[];

  const [activeCat, setActiveCat] = useState<string>("all");
  const [searchMode, setSearchMode] = useState<boolean>(false);
  const [q, setQ] = useState("");
  const [visibleCount, setVisibleCount] = useState<number>(DEFAULT_ROWS * CARDS_PER_ROW);

  const filtered = useMemo(() => {
    let base = courses;
    if (!searchMode) {
      base = activeCat === "all" ? courses : courses.filter(c => c.categories.includes(activeCat));
    } else {
      const term = q.trim().toLowerCase();
      base = term ? courses.filter(c => c.title.toLowerCase().includes(term)) : courses;
    }
    return base;
  }, [courses, activeCat, searchMode, q]);

  const visible = filtered.slice(0, visibleCount);
  const hasMore = visibleCount < filtered.length;

  const onViewMore = () => setVisibleCount(n => Math.min(n + STEP, filtered.length));
  const onViewLess = () => {
    setVisibleCount(DEFAULT_ROWS * CARDS_PER_ROW);
    document.getElementById("courses-root")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const enterSearch = () => {
    setSearchMode(true);
    setQ("");
    setVisibleCount(DEFAULT_ROWS * CARDS_PER_ROW);
  };
  const backToCategories = () => {
    setSearchMode(false);
    setQ("");
    setVisibleCount(DEFAULT_ROWS * CARDS_PER_ROW);
  };

  return (
    <section id="courses-root" className="mx-auto w-full max-w-6xl p-4 md:p-6">
      <div className="mb-5 text-center">
        <p className="text-xs font-medium tracking-widest text-emerald-700">
          FIND THE COURSE RIGHT FOR YOUR GOALS
        </p>
        <h2 className="mt-2 text-2xl font-bold tracking-tight md:text-3xl">
          Explore From Over 400+ Courses
        </h2>
      </div>

      {!searchMode ? (
        <div className="mb-6 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <CategoryTabs
            categories={categories}
            activeId={activeCat}
            onChange={(id) => {
              setActiveCat(id);
              setVisibleCount(DEFAULT_ROWS * CARDS_PER_ROW);
            }}
          />
          <div className="flex justify-end">
            <Button variant="outline" className="h-9 gap-2 rounded-full px-3" onClick={enterSearch} title="Search courses">
              <Search className="h-4 w-4" />
            </Button>
          </div>
        </div>
      ) : (
        <div className="mb-6 grid grid-cols-1 items-center gap-3 md:grid-cols-[auto,1fr,auto]">
          <button
            onClick={backToCategories}
            className="inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-sm hover:bg-gray-50"
          >
            <ChevronLeft className="h-4 w-4" />
            Back to Categories
          </button>

          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <input
              value={q}
              onChange={(e) => {
                setQ(e.target.value);
                setVisibleCount(DEFAULT_ROWS * CARDS_PER_ROW);
              }}
              placeholder="What do you want to learn today?"
              className="w-full rounded-full border bg-white pl-9 pr-24 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-600/30"
            />
            <Button className="absolute right-1 top-1/2 h-8 -translate-y-1/2 rounded-full px-4">
              Search
            </Button>
          </div>

          <div className="hidden md:block" />
        </div>
      )}

      <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
        {visible.map((course) => (
          <CourseCard key={course.id} course={course} />
        ))}
      </div>

      <div className="mt-6 flex justify-center">
        {hasMore ? (
          <button onClick={onViewMore} className="inline-flex items-center gap-1 text-sm font-medium text-gray-700 hover:text-gray-900">
            View more courses <span aria-hidden>↗</span>
          </button>
        ) : filtered.length > DEFAULT_ROWS * CARDS_PER_ROW ? (
          <button onClick={onViewLess} className="inline-flex items-center gap-1 text-sm font-medium text-gray-700 hover:text-gray-900">
            View less courses <span aria-hidden>↘</span>
          </button>
        ) : null}
      </div>
    </section>
  );
}
