import { cn } from "@/lib/cn";

export type Category = { id: string; name: string };

type Props = {
  categories: Category[];
  activeId: string;
  onChange: (id: string) => void;
};

export default function CategoryTabs({ categories, activeId, onChange }: Props) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      {categories.map((c) => {
        const active = c.id === activeId;
        return (
          <button
            key={c.id}
            onClick={() => onChange(c.id)}
            className={cn(
              "rounded-full border px-3 py-1.5 text-sm transition",
              active
                ? "border-emerald-600 bg-emerald-50 text-emerald-700"
                : "border-gray-200 bg-white text-gray-700 hover:bg-gray-50"
            )}
          >
            {c.name}
          </button>
        );
      })}
    </div>
  );
}
