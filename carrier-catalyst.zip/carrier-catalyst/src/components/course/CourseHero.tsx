import { CheckCircle2, Clock3, Users, BadgeIndianRupee } from "lucide-react";
import type { CourseVM } from "@/lib/paths";

/**
 * Premium, responsive hero for course details.
 * Pulls content from course.hero if present, otherwise falls back to course fields.
 */
export default function CourseHero({ course }: { course: CourseVM }) {
  const h = (course as any).hero || {};
  const label = h.label || course.tag;
  const title = h.title || course.title;
  const subtitle = h.subtitle;
  const bullets: string[] = Array.isArray(h.bullets) ? h.bullets : [];
  const heroImage: string = h.image || course.image;

  const primaryText = h.ctaPrimaryText || "Enroll now";
  const secondaryText = h.ctaSecondaryText || "Download syllabus";
  const secondaryHref: string | undefined =
    h.ctaSecondaryHref || (course as any).syllabusUrl;

  return (
    <section className="mt-6 overflow-hidden rounded-3xl border border-slate-200 bg-white/80 shadow-[0_20px_60px_rgba(2,6,23,0.08)] backdrop-blur supports-[backdrop-filter]:bg-white/70">
      <div className="relative grid gap-6 md:grid-cols-2">
        {/* Background glow */}
        <div className="pointer-events-none absolute inset-0 -z-10">
          <div className="absolute -top-24 -left-24 h-72 w-72 rounded-full bg-sky-200/40 blur-3xl" />
          <div className="absolute -bottom-24 -right-24 h-72 w-72 rounded-full bg-indigo-200/40 blur-3xl" />
        </div>

        {/* Left: Copy */}
        <div className="px-6 py-7 md:px-10 md:py-10">
          {label && (
            <span className="inline-block rounded-full border border-sky-200 bg-sky-50 px-3 py-1 text-xs font-semibold text-sky-700">
              {label}
            </span>
          )}

          <h1 className="mt-3 text-3xl font-black tracking-tight text-slate-900 md:text-4xl">
            {title}
          </h1>

          {subtitle && (
            <p className="mt-2 max-w-prose text-sm text-slate-700 md:text-[15px]">
              {subtitle}
            </p>
          )}

          {/* Bullets */}
          {bullets.length > 0 && (
            <ul className="mt-4 space-y-2">
              {bullets.map((b, i) => (
                <li key={i} className="flex items-start gap-2 text-[15px] text-slate-800">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
                  <span>{b}</span>
                </li>
              ))}
            </ul>
          )}

          {/* Stats row */}
          <div className="mt-6 flex flex-wrap gap-4 text-sm text-slate-700">
            {Array.isArray((course as any).modes) && (course as any).modes.length > 0 && (
              <div className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5">
                <span className="font-medium">Modes:</span>
                <span className="text-slate-600">{(course as any).modes.join(" / ")}</span>
              </div>
            )}
            {(course as any).hours && (
              <div className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5">
                <Clock3 className="h-4 w-4 text-slate-500" />
                <span>{(course as any).hours} Hrs</span>
              </div>
            )}
            {(course as any).enrolled && (
              <div className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5">
                <Users className="h-4 w-4 text-slate-500" />
                <span>{((course as any).enrolled as number).toLocaleString()} Enrolled</span>
              </div>
            )}
            {(course as any).priceInr && (
              <div className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5">
                <BadgeIndianRupee className="h-4 w-4 text-emerald-600" />
                <span className="font-semibold text-emerald-700">
                  ₹ {((course as any).priceInr as number).toLocaleString("en-IN")}
                </span>
              </div>
            )}
          </div>

          {/* CTAs */}
          <div className="mt-7 flex flex-wrap gap-3">
            <button className="rounded-lg bg-sky-600 px-5 py-2.5 text-sm font-medium text-white shadow hover:bg-sky-700">
              {primaryText}
            </button>
            {secondaryText && (
              secondaryHref ? (
                <a
                  href={secondaryHref}
                  className="rounded-lg border border-slate-300 bg-white px-5 py-2.5 text-sm font-medium text-slate-800 shadow-sm hover:bg-slate-50"
                >
                  {secondaryText}
                </a>
              ) : (
                <button className="rounded-lg border border-slate-300 bg-white px-5 py-2.5 text-sm font-medium text-slate-800 shadow-sm hover:bg-slate-50">
                  {secondaryText}
                </button>
              )
            )}
          </div>
        </div>

        {/* Right: Image */}
        <div className="relative">
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900/5 to-transparent md:hidden" />
          <img
            src={heroImage}
            alt={title}
            loading="lazy"
            className="h-64 w-full object-cover md:h-full"
          />
        </div>
      </div>
    </section>
  );
}
