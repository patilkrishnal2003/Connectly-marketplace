import { useMemo, useState } from "react";
import { ChevronDown } from "lucide-react";
import type { Course } from "@/types";

type FaqItem = NonNullable<Course["faqs"]>[number];

export default function CourseFaq({
  items,
}: {
  items: FaqItem[];
  }) {
  // show 5 initially (or fewer if items < 5)
  const initialCount = useMemo(() => Math.min(5, items.length), [items.length]);
  const [visibleCount, setVisibleCount] = useState(initialCount);
  const [openIndex, setOpenIndex] = useState<number | null>(null); // single-open accordion

  const visibleItems = items.slice(0, visibleCount);
  const canShowMore = items.length > visibleCount;
  const canShowLess = items.length > initialCount && !canShowMore;

  const toggle = (idx: number) => {
    setOpenIndex((prev) => (prev === idx ? null : idx));
  };

  const onMore = () => setVisibleCount((v) => Math.min(v + 5, items.length));
  const onLess = () => {
    setVisibleCount(initialCount);
    setOpenIndex(null);
  };

  return (
    <section className="mx-auto mt-10 max-w-5xl">
      {/* Centered heading */}
      <div className="mb-6 text-center">
        <h2 className="text-xl font-bold text-slate-900">Course FAQs</h2>
        <p className="mt-1 text-sm text-slate-600">Clear answers to help you decide faster.</p>
      </div>

      {/* FAQ box */}
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <ul className="divide-y divide-slate-200">
          {visibleItems.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <li key={idx} className="bg-slate-50/40">
                <button
                  type="button"
                  onClick={() => toggle(idx)}
                  className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left transition hover:bg-slate-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-500/40"
                  aria-expanded={isOpen}
                >
                  <span className="text-[15px] font-medium text-slate-900">{faq.question}</span>
                  <ChevronDown
                    className={`h-4 w-4 shrink-0 text-slate-500 transition-transform ${
                      isOpen ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {/* Smooth collapse/expand */}
                <div
                  className={`grid overflow-hidden transition-all duration-300 ${
                    isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                  }`}
                >
                  <div className="min-h-0">
                    <div className="px-5 pb-5 text-sm leading-6 text-slate-700">
                      {Array.isArray(faq.answer) ? (
                        <ul className="list-disc pl-5">
                          {faq.answer.map((line, i) => (
                            <li key={i} className="mb-1">
                              {line}
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p>{faq.answer}</p>
                      )}

                      {faq.links?.length ? (
                        <ul className="mt-3 list-disc pl-5">
                          {faq.links.map((l, i) => (
                            <li key={i}>
                              <a href={l.href} className="text-sky-600 hover:underline">
                                {l.label}
                              </a>
                            </li>
                          ))}
                        </ul>
                      ) : null}
                    </div>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      </div>

      {/* Centered controls */}
      {items.length > initialCount && (
        <div className="mt-4 flex justify-center">
          {canShowMore ? (
            <button
              onClick={onMore}
              className="rounded-full border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 shadow-sm hover:bg-slate-50"
            >
              View more
            </button>
          ) : (
            canShowLess && (
              <button
                onClick={onLess}
                className="rounded-full border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 shadow-sm hover:bg-slate-50"
              >
                View less
              </button>
            )
          )}
        </div>
      )}
    </section>
  );
}
