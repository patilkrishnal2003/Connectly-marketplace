import { useMemo, useRef } from "react";
import { Link } from "react-router-dom";
import { ChevronLeft, ChevronRight, Clock, ArrowRight } from "lucide-react";

import rawCourses from "@/data/courses.json";
import type { Course } from "@/types";
import { categorySlugById, coursePath, normalizeCourse } from "@/lib/paths";

type Props = {
  /** Category whose related courses to show */
  contextCategoryId: string;
  /** Exclude the current course */
  excludeCourseId?: string;
  excludeCourseSlug?: string;
  title?: string;
  subtitle?: string;
};

export default function CourseSlider({
  contextCategoryId,
  excludeCourseId,
  excludeCourseSlug,
  title = "Explore more courses",
  subtitle,
}: Props) {
  const scrollerRef = useRef<HTMLDivElement | null>(null);
  const contextCatSlug = categorySlugById(contextCategoryId);

  const items = useMemo(() => {
    return (rawCourses as Course[])
      .filter(
        (c) => Array.isArray(c.categories) && c.categories.includes(contextCategoryId)
      )
      .map(normalizeCourse)
      .filter(
        (c) =>
          (excludeCourseId ? c.id !== excludeCourseId : true) &&
          (excludeCourseSlug ? c.slug !== excludeCourseSlug : true)
      );
  }, [contextCategoryId, excludeCourseId, excludeCourseSlug]);

  if (!items.length) return null;

  const scrollBy = (px: number) =>
    scrollerRef.current?.scrollBy({ left: px, behavior: "smooth" });

  const tagStyle = (tag?: string) => {
    if (!tag) return "hidden";
    const t = tag.toLowerCase();
    if (t.includes("trend"))
      return "bg-amber-100 text-amber-900 ring-amber-200";
    if (t.includes("recom"))
      return "bg-emerald-100 text-emerald-800 ring-emerald-200";
    return "bg-sky-100 text-sky-800 ring-sky-200";
  };

  return (
    <section className="mt-12">
      <div className="mb-6 text-center">
        <h2 className="text-xl font-bold text-slate-900">{title}</h2>
        {subtitle && <p className="mt-1 text-sm text-slate-600">{subtitle}</p>}
      </div>

      <div className="relative">
        {/* fade edges */}
        <div className="pointer-events-none absolute left-0 top-0 h-full w-10 bg-gradient-to-r from-white to-transparent" />
        <div className="pointer-events-none absolute right-0 top-0 h-full w-10 bg-gradient-to-l from-white to-transparent" />

        <div
          ref={scrollerRef}
          className="flex gap-5 overflow-x-auto scroll-smooth px-1 py-1
                     snap-x snap-mandatory
                     [-ms-overflow-style:'none'] [scrollbar-width:none]
                     [&::-webkit-scrollbar]:hidden"
        >
          {items.map((c) => (
            <Link
              key={c.id}
              to={coursePath(contextCatSlug, c.slug)}
              className="group w-[340px] snap-start"
            >
              {/* gradient border wrapper */}
              <div className="rounded-2xl bg-gradient-to-r from-sky-200 via-slate-200 to-indigo-200 p-[1px]">
                <div className="relative flex h-32 items-center gap-4 rounded-2xl bg-white p-3 shadow-sm ring-1 ring-slate-200 transition-all duration-300 group-hover:-translate-y-0.5 group-hover:shadow-lg">
                  {/* thumbnail */}
                  <div className="relative h-24 w-28 overflow-hidden rounded-xl ring-1 ring-slate-200/70">
                    <img
                      src={c.image}
                      alt={c.title}
                      loading="lazy"
                      className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.05]"
                    />
                    {/* tag */}
                    <span
                      className={`absolute left-1.5 top-1.5 rounded-md px-2 py-0.5 text-[10px] font-semibold ring-1 ${tagStyle(
                        (c as any).tag
                      )}`}
                    >
                      {(c as any).tag}
                    </span>
                  </div>

                  {/* text */}
                  <div className="min-w-0 pr-7">
                    <h3 className="line-clamp-2 text-[15px] font-semibold leading-5 text-slate-900">
                      {c.title}
                    </h3>

                    <div className="mt-2 flex flex-wrap items-center gap-2">
                      {c.duration && (
                        <span className="inline-flex items-center gap-1 rounded-full bg-slate-50 px-2.5 py-1 text-xs font-medium text-slate-700 ring-1 ring-slate-200">
                          <Clock className="h-3.5 w-3.5" />
                          {c.duration}
                        </span>
                      )}
                      <span className="hidden sm:inline-flex items-center gap-1 rounded-full bg-sky-50 px-2.5 py-1 text-[11px] font-semibold text-sky-700 ring-1 ring-sky-200">
                        View
                        <ArrowRight className="h-3.5 w-3.5" />
                      </span>
                    </div>
                  </div>

                  <ArrowRight className="absolute right-3 top-3 h-4 w-4 text-slate-400 transition-transform group-hover:translate-x-0.5" />
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* nav buttons */}
        <button
          aria-label="Scroll left"
          onClick={() => scrollBy(-360)}
          className="absolute -left-2 top-1/2 -translate-y-1/2 rounded-full bg-white p-2 text-slate-700 shadow ring-1 ring-slate-200 hover:bg-slate-50"
        >
          <ChevronLeft className="h-4 w-4" />
        </button>
        <button
          aria-label="Scroll right"
          onClick={() => scrollBy(360)}
          className="absolute -right-2 top-1/2 -translate-y-1/2 rounded-full bg-white p-2 text-slate-700 shadow ring-1 ring-slate-200 hover:bg-slate-50"
        >
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>
    </section>
  );
}
