import { ArrowRight } from "lucide-react";

export type CourseObjectiveItem = { title: string; description?: string };
export type CourseObjectivesData = {
  eyebrow?: string;   // small label above title
  title?: string;     // main heading
  items: CourseObjectiveItem[];
};

export default function CourseObjectives({
  data,
  courseTitle,
  className = "",
}: {
  data: CourseObjectivesData;
  courseTitle?: string;
  className?: string;
}) {
  if (!data?.items?.length) return null;

  const eyebrow =
    data.eyebrow ??
    (courseTitle
      ? `What you'll learn in the ${courseTitle} certification training`
      : `What you'll learn in this course`);

  const heading = data.title ?? "Learning Objectives";

  return (
    <section
      className={`relative overflow-hidden rounded-3xl border border-slate-200 bg-gradient-to-b from-sky-50/50 via-white to-white p-6 md:p-10 shadow-sm ${className}`}
    >
      {/* decorative ambient glows */}
      <div className="pointer-events-none absolute -top-24 -right-24 h-64 w-64 rounded-full bg-sky-100/60 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-24 -left-24 h-64 w-64 rounded-full bg-emerald-100/50 blur-3xl" />

      {/* header */}
      <div className="relative">
        <span className="inline-flex items-center rounded-full bg-sky-50 px-3 py-1 text-[11px] font-semibold uppercase tracking-wide text-sky-700 ring-1 ring-sky-200">
          {eyebrow}
        </span>
        <h2 className="mt-2 bg-gradient-to-r from-slate-900 to-slate-700 bg-clip-text text-2xl font-extrabold text-transparent md:text-3xl">
          {heading}
        </h2>
      </div>

      {/* cards */}
      <div className="relative mt-7 grid gap-4 sm:grid-cols-2">
        {data.items.map((it, i) => (
          <article
            key={i}
            className="group relative flex items-start gap-4 rounded-2xl bg-white/80 p-5 shadow-[inset_0_0_0_1px_rgba(15,23,42,.06),0_10px_30px_-12px_rgba(2,132,199,.25)] ring-1 ring-slate-200 backdrop-blur-sm transition-all duration-300 hover:-translate-y-1 hover:bg-white hover:shadow-[inset_0_0_0_1px_rgba(2,132,199,.15),0_18px_40px_-18px_rgba(2,132,199,.35)] hover:ring-sky-300 focus-within:-translate-y-1"
          >
            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-sky-50 to-white text-sky-700 ring-1 ring-sky-200 shadow-sm transition-transform duration-300 group-hover:scale-105">
              <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5" />
            </div>

            <div className="min-w-0">
              <h3 className="truncate text-[15px] font-semibold text-slate-900">
                {it.title}
              </h3>
              {it.description && (
                <p className="mt-1 text-sm leading-6 text-slate-600">
                  {it.description}
                </p>
              )}
            </div>

            {/* subtle active accent on hover */}
            <span className="pointer-events-none absolute inset-0 rounded-2xl ring-0 ring-sky-300/0 transition-all duration-300 group-hover:ring-2 group-hover:ring-sky-300/30" />
          </article>
        ))}
      </div>
    </section>
  );
}
