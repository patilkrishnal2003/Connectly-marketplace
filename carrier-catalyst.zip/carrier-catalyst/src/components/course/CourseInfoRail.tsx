import { CalendarDays, Clock3, BookOpen } from "lucide-react";

type Props = {
  /** e.g. "2025-08-25" or Date */
  closesOn?: string | Date;
  /** e.g. "11 Months" or "16 Hrs" */
  duration?: string;
  /** e.g. "Live, Online, Interactive" (or course.modes.join(", ")) */
  format?: string;
  /** set false if you don't want full-bleed */
  fullBleed?: boolean;
  className?: string;
};

function formatDate(value?: string | Date) {
  if (!value) return undefined;
  const d = typeof value === "string" ? new Date(value) : value;
  return d.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

export default function CourseInfoRail({
  closesOn,
  duration,
  format,
  fullBleed = true,
  className = "",
}: Props) {
  const dateText = formatDate(closesOn);

  const items = [
    { icon: Clock3, label: "Application closes on", value: dateText },
    { icon: CalendarDays, label: "Program duration", value: duration },
    { icon: BookOpen, label: "Learning format", value: format },
  ].filter((i) => Boolean(i.value));

  if (items.length === 0) return null;

  return (
    <div className={fullBleed ? "relative left-1/2 right-1/2 -mx-[50vw] w-screen" : ""}>
      <section
        role="region"
        aria-label="Course information"
        className={`bg-sky-50 border-y border-sky-100 py-5 md:py-6 ${className}`}
      >
        <div className="mx-auto max-w-6xl px-4">
          <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
            {items.map((it, idx) => {
              const Icon = it.icon;
              return (
                <div
                  key={idx}
                  className="flex items-center gap-3 md:gap-4 md:pl-4 md:border-l md:border-sky-100 first:md:border-l-0 first:md:pl-0"
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white text-slate-700 shadow-sm ring-1 ring-sky-200">
                    <Icon className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      {it.label}
                    </div>
                    <div className="text-[15px] font-semibold text-slate-900">
                      {it.value}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}
