import { BadgeIndianRupee, Clock3, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/cn";
import { categorySlugById, coursePath } from "@/lib/paths";
import { useNavigate } from "react-router-dom";

export type Course = {
  id: string;
  slug: string;               // <-- add this
  title: string;
  modes: string[];
  hours: number;
  enrolled: number;
  priceInr: number;
  image: string;
  badges?: string[];
  categories: string[];       // first item is treated as the primary category
  cta?: "contact" | "curriculum";
};

export function CourseCard({ course }: { course: Course }) {
  const navigate = useNavigate();

  // Build URL: /{categorySlug}/{courseSlug}
  const primaryCatId = course.categories[0];
  const catSlug = categorySlugById(primaryCatId);
  const to = coursePath(catSlug, course.slug);

  const price = `₹ ${course.priceInr.toLocaleString("en-IN")}`;

  const go = () => navigate(to);

  return (
    <Card
      role="link"
      tabIndex={0}
      onClick={go}
      onKeyDown={(e) => e.key === "Enter" && go()}
      className="group cursor-pointer overflow-hidden border border-gray-200 shadow-sm transition hover:shadow-md"
    >
      {/* image */}
      <div className="relative">
        <img
          src={course.image}
          alt={course.title}
          className="h-40 w-full object-cover transition duration-500 group-hover:scale-[1.02]"
          loading="lazy"
        />
        {/* badges (top-right) */}
        <div className="pointer-events-none absolute right-2 top-2 flex gap-2">
          {course.badges?.map((b) => (
            <span
              key={b}
              className={cn(
                "rounded-md px-2 py-1 text-[11px] font-semibold text-white",
                b === "Recommended" ? "bg-indigo-600" : "bg-rose-600"
              )}
            >
              {b}
            </span>
          ))}
        </div>
        {/* modes (top-left faint) */}
        <span className="absolute left-3 top-3 rounded-md bg-white/80 px-2 py-0.5 text-[11px] font-medium text-gray-700 shadow">
          {course.modes.join(" / ")}
        </span>
      </div>

      <CardHeader className="pb-3">
        <CardTitle className="text-[15px]">{course.title}</CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* stats row */}
        <div className="flex items-center justify-between text-xs text-gray-600">
          <div className="flex items-center gap-2">
            <Clock3 className="h-4 w-4" />
            <span>{course.hours} Hrs</span>
            <span className="mx-2">•</span>
            <Users className="h-4 w-4" />
            <span>{course.enrolled.toLocaleString()} Enrolled</span>
          </div>
          <div className="flex items-center gap-1 font-semibold text-emerald-700">
            <BadgeIndianRupee className="h-4 w-4" />
            <span>{price}</span>
          </div>
        </div>

        {/* CTA row (they navigate to the same detail page) */}
        <div className="flex gap-2">
          <Button
            variant="outline"
            className="flex-1"
            onClick={(e) => {
              e.stopPropagation();
              go();
            }}
          >
            View courses
          </Button>
          <Button
            className="flex-1"
            onClick={(e) => {
              e.stopPropagation();
              go();
            }}
          >
            {course.cta === "contact" ? "Contact Advisor" : "Curriculum"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
