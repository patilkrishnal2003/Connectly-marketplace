// src/components/course/InfoRequestCard.tsx
import { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { getCourseBySlug } from "@/lib/paths";
import { Loader2, Mail, Phone, ShieldCheck, User2, Building2, CheckCircle2 } from "lucide-react";

/**
 * ⚙️ Configure these 3 values:
 * 1) FORMSPREE_ENDPOINT — create a form at https://formspree.io, copy your endpoint (looks like /f/abcdwxyz)
 * 2) RECIPIENT_EMAIL    — (optional) included in payload + mailto fallback
 * 3) ADVISOR_PHONE      — used by the "Talk to Advisor" button
 */
const FORMSPREE_ENDPOINT = "https://formspree.io/f/yourFormId"; // ← replace
const RECIPIENT_EMAIL = "xxx@gmail.com";                          // ← replace
const ADVISOR_PHONE = "+91-90000-00000";                          // ← replace

type Props = {
  /** Optional: if omitted we infer from route (/.../:courseSlug) */
  courseTitle?: string;
  className?: string;
};

const EXP_OPTIONS = ["0-1", "1-3", "3-5", "5-10", "10-15", "15-50", "20+"] as const;
type Exp = (typeof EXP_OPTIONS)[number];

export default function InfoRequestCard({ courseTitle, className = "" }: Props) {
  // --- Infer course title from route if not passed as prop ---
  const { courseSlug = "" } = useParams();
  const courseFromRoute = useMemo(() => getCourseBySlug(courseSlug || ""), [courseSlug]);
  const resolvedCourseTitle = courseTitle || courseFromRoute?.title || "Course Inquiry";

  // --- Form state ---
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [inquiryFor, setInquiryFor] = useState<"self" | "company">("self");
  const [exp, setExp] = useState<Exp | "">("");
  const [agree, setAgree] = useState(false);

  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [sending, setSending] = useState(false);

  // Success/error banner
  const [banner, setBanner] = useState<null | { type: "ok" | "err"; msg: string }>(null);
  useEffect(() => {
    if (!banner) return;
    const t = setTimeout(() => setBanner(null), 6000);
    return () => clearTimeout(t);
  }, [banner]);

  // --- Validation ---
  const errors = useMemo(() => {
    const e: Record<string, string> = {};
    if (!fullName.trim() || fullName.trim().length < 2) e.fullName = "Please enter your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) e.email = "Enter a valid email address.";
    const digits = phone.replace(/\D/g, "");
    if (digits.length < 7 || digits.length > 15) e.phone = "Enter a valid phone number.";
    if (!exp) e.exp = "Select total experience.";
    if (!agree) e.agree = "You must accept the Privacy Policy.";
    return e;
  }, [fullName, email, phone, exp, agree]);

  const hasError = (key: string) => Boolean(touched[key] && errors[key]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setTouched({ fullName: true, email: true, phone: true, exp: true, agree: true });
    if (Object.keys(errors).length) return;

    setSending(true);
    try {
      const payload = {
        to: RECIPIENT_EMAIL,
        courseTitle: resolvedCourseTitle,
        courseSlug,
        fullName,
        email,
        phone,
        inquiryFor,
        experience: exp,
        consent: agree ? "yes" : "no",
        _subject: `Request for info: ${resolvedCourseTitle}`,
        _gotcha: "", // spam honeypot (Formspree-friendly)
      };

      const res = await fetch(FORMSPREE_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const msg = await safeMsg(res);
        throw new Error(msg || "Unable to send right now.");
      }

      // Success banner + reset
      setBanner({ type: "ok", msg: "Thank you! Our program advisor will contact you soon." });
      setFullName("");
      setEmail("");
      setPhone("");
      setInquiryFor("self");
      setExp("");
      setAgree(false);
      setTouched({});

    } catch (err: any) {
      setBanner({ type: "err", msg: err?.message || "Unable to send. Please try again." });
      // Fallback: open user's mail client (last resort)
      const subject = encodeURIComponent(`Request for info: ${resolvedCourseTitle}`);
      const body = encodeURIComponent(
        `Course: ${resolvedCourseTitle}\nSlug: ${courseSlug}\nName: ${fullName}\nEmail: ${email}\nPhone: ${phone}\nFor: ${inquiryFor}\nExperience: ${exp}\nConsent: ${agree ? "Yes" : "No"}`
      );
      window.open(`mailto:${RECIPIENT_EMAIL}?subject=${subject}&body=${body}`, "_blank");
    } finally {
      setSending(false);
    }
  }

  return (
    <aside
      className={`sticky top-20 rounded-2xl border border-sky-200 bg-gradient-to-b from-sky-50/70 via-white to-white p-4 shadow-lg ring-1 ring-sky-100 ${className}`}
    >
      {/* Success / Error banner */}
      <div
        className={`mb-3 overflow-hidden rounded-xl transition-all duration-300 ${
          banner ? "max-h-14 opacity-100" : "max-h-0 opacity-0"
        }`}
        aria-live="polite"
      >
        {banner && (
          <div
            className={`flex items-center gap-2 px-3 py-2 text-sm font-medium text-white ${
              banner.type === "ok" ? "bg-emerald-600" : "bg-rose-600"
            } rounded-xl`}
          >
            <CheckCircle2 className="h-4 w-4" />
            <span>{banner.msg}</span>
          </div>
        )}
      </div>

      {/* Header */}
      <div className="mb-3 flex items-center justify-between">
        <div className="text-sm font-semibold text-slate-900">Request more information</div>
        <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[11px] font-semibold text-emerald-700 ring-1 ring-emerald-100">
          <ShieldCheck className="h-3.5 w-3.5" />
          Quick callback
        </span>
      </div>

      <form onSubmit={onSubmit} noValidate>
        {/* Name */}
        <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-slate-600">
          Full name
        </label>
        <div className={`mb-3 flex items-center overflow-hidden rounded-xl border bg-white ${hasError("fullName") ? "border-rose-300" : "border-slate-200"}`}>
          <div className="grid h-10 w-10 place-items-center text-slate-400">
            <User2 className="h-4 w-4" />
          </div>
          <input
            type="text"
            className="h-10 w-full bg-transparent text-sm outline-none"
            placeholder="Your full name"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            onBlur={() => setTouched((t) => ({ ...t, fullName: true }))}
          />
        </div>
        {hasError("fullName") && <p className="mb-2 text-xs text-rose-600">{errors.fullName}</p>}

        {/* Email */}
        <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-slate-600">
          Email
        </label>
        <div className={`mb-3 flex items-center overflow-hidden rounded-xl border bg-white ${hasError("email") ? "border-rose-300" : "border-slate-200"}`}>
          <div className="grid h-10 w-10 place-items-center text-slate-400">
            <Mail className="h-4 w-4" />
          </div>
          <input
            type="email"
            className="h-10 w-full bg-transparent text-sm outline-none"
            placeholder="you@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            onBlur={() => setTouched((t) => ({ ...t, email: true }))}
          />
        </div>
        {hasError("email") && <p className="mb-2 text-xs text-rose-600">{errors.email}</p>}

        {/* Phone */}
        <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-slate-600">
          Phone number
        </label>
        <div className={`mb-3 flex items-center overflow-hidden rounded-xl border bg-white ${hasError("phone") ? "border-rose-300" : "border-slate-200"}`}>
          <div className="grid h-10 w-10 place-items-center text-slate-400">
            <Phone className="h-4 w-4" />
          </div>
        <input
            inputMode="tel"
            className="h-10 w-full bg-transparent text-sm outline-none"
            placeholder="+91 98765 43210"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            onBlur={() => setTouched((t) => ({ ...t, phone: true }))}
          />
        </div>
        {hasError("phone") && <p className="mb-2 text-xs text-rose-600">{errors.phone}</p>}

        {/* Inquiry for */}
        <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-slate-600">
          Inquiry for
        </label>
        <div className="mb-3 flex gap-2">
          <label className={`flex flex-1 cursor-pointer items-center justify-center gap-2 rounded-xl border px-3 py-2 text-sm ${inquiryFor === "self" ? "border-sky-300 bg-sky-50 text-sky-900" : "border-slate-200 bg-white text-slate-700"}`}>
            <input type="radio" name="inq" className="sr-only" checked={inquiryFor === "self"} onChange={() => setInquiryFor("self")} />
            <User2 className="h-4 w-4" /> Myself
          </label>
          <label className={`flex flex-1 cursor-pointer items-center justify-center gap-2 rounded-xl border px-3 py-2 text-sm ${inquiryFor === "company" ? "border-sky-300 bg-sky-50 text-sky-900" : "border-slate-200 bg-white text-slate-700"}`}>
            <input type="radio" name="inq" className="sr-only" checked={inquiryFor === "company"} onChange={() => setInquiryFor("company")} />
            <Building2 className="h-4 w-4" /> My company
          </label>
        </div>

        {/* Experience */}
        <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-slate-600">
          Total work experience
        </label>
        <select
          className={`mb-3 w-full rounded-xl border bg-white px-3 py-2 text-sm ${hasError("exp") ? "border-rose-300" : "border-slate-200"}`}
          value={exp}
          onChange={(e) => setExp(e.target.value as Exp)}
          onBlur={() => setTouched((t) => ({ ...t, exp: true }))}
        >
          <option value="" disabled>Select</option>
          {EXP_OPTIONS.map((o) => (
            <option key={o} value={o}>{o} years</option>
          ))}
        </select>
        {hasError("exp") && <p className="mb-2 text-xs text-rose-600">{errors.exp}</p>}

        {/* Consent */}
        <label className="mb-3 flex items-start gap-2 text-xs text-slate-700">
          <input
            type="checkbox"
            className="mt-0.5 h-4 w-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500"
            checked={agree}
            onChange={(e) => setAgree(e.target.checked)}
            onBlur={() => setTouched((t) => ({ ...t, agree: true }))}
          />
          <span>
            By providing your contact details, you agree to our{" "}
            <a href="/privacy" className="text-sky-700 underline-offset-2 hover:underline">
              Privacy Policy
            </a>.
          </span>
        </label>
        {hasError("agree") && <p className="mb-3 text-xs text-rose-600">{errors.agree}</p>}

        {/* Submit */}
        <button
          type="submit"
          disabled={sending}
          className="mb-2 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-3 text-sm font-semibold text-white shadow hover:bg-slate-800 disabled:opacity-70"
        >
          {sending ? (<><Loader2 className="h-4 w-4 animate-spin" /> Sending…</>) : ("Submit")}
        </button>

        {/* Advisor CTA */}
        <a
          href={`tel:${ADVISOR_PHONE}`}
          className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm font-semibold text-slate-800 hover:bg-slate-50"
        >
          <Phone className="h-4 w-4" />
          Talk to Advisor
        </a>
      </form>
    </aside>
  );
}

async function safeMsg(res: Response) {
  try {
    const data = await res.json();
    return data?.error || data?.message || "";
  } catch {
    return "";
  }
}
