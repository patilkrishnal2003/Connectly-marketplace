// src/components/course/CourseLearningPath.tsx
import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { ChevronDown } from "lucide-react";

export type LearningModule = {
  id?: string;
  title: string;
  summary?: string;
  bullets?: string[];
  duration?: string;
  resources?: { label: string; href: string }[];
};

export type LearningPathData = {
  title?: string;
  modules: LearningModule[];
};

export default function CourseLearningPath({
  path,
  className = "",
}: {
  path: LearningPathData;
  className?: string;
}) {
  const modules = path.modules ?? [];
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const containerRef = useRef<HTMLDivElement | null>(null);
  const dotRefs = useRef<(HTMLDivElement | null)[]>([]);
  const rowRefs = useRef<(HTMLLIElement | null)[]>([]);

  const [trackLeft, setTrackLeft] = useState(0);
  const [trackTop, setTrackTop] = useState(0);
  const [trackBottom, setTrackBottom] = useState(0);
  const [progressHeight, setProgressHeight] = useState(0);

  // cache for precise geometry
  const centersRef = useRef<{ cx: number; cy: number }[]>([]);
  const halfHeightsRef = useRef<number[]>([]);

  // keep the progress just *inside* the active dot so it never overshoots
  const STOP_EPS = 2;

  const measure = () => {
    const root = containerRef.current;
    if (!root) return;

    const dots = dotRefs.current.filter(Boolean);
    if (dots.length === 0) {
      setProgressHeight(0);
      return;
    }

    const rootRect = root.getBoundingClientRect();

    const centers = dots.map((d) => {
      const r = (d as HTMLDivElement).getBoundingClientRect();
      return {
        cx: r.left - rootRect.left + r.width / 2,
        cy: r.top - rootRect.top + r.height / 2,
      };
    });
    const halfHeights = dots.map((d) => (d as HTMLDivElement).offsetHeight / 2);

    centersRef.current = centers;
    halfHeightsRef.current = halfHeights;

    // rail geometry
    const left = centers[0].cx - 1.5; // track is 3px
    setTrackLeft(left);

    const top = centers[0].cy;
    setTrackTop(top);

    const bottomGap = rootRect.height - centers[centers.length - 1].cy;
    setTrackBottom(bottomGap);

    // progress line reaches *bottom of active dot* (minus epsilon)
    if (openIndex === null) {
      setProgressHeight(0);
    } else {
      const toBottom =
        centers[openIndex].cy + halfHeights[openIndex] - top - STOP_EPS;
      setProgressHeight(Math.max(0, Math.round(toBottom)));
    }
  };

  // Measure whenever the open item changes
  useLayoutEffect(measure, [openIndex, modules.length]);

  // Keep measuring during/after transitions with ResizeObserver + scheduled reflows
  useEffect(() => {
    const root = containerRef.current;
    if (!root) return;

    const ro = new ResizeObserver(() => measure());
    ro.observe(root);

    // also do a couple of extra reads right after toggle to catch animation
    // next frame
    const raf1 = requestAnimationFrame(() => {
      measure();
      // one more frame later
      requestAnimationFrame(measure);
    });
    // and one after our transition time (~300ms)
    const t = setTimeout(measure, 360);

    return () => {
      ro.disconnect();
      cancelAnimationFrame(raf1);
      clearTimeout(t);
    };
    // we want this to run each time layout meaningfully changes:
  }, [openIndex]);

  // smooth scroll focused row into view
  useEffect(() => {
    if (openIndex === null) return;
    rowRefs.current[openIndex]?.scrollIntoView({
      block: "nearest",
      behavior: "smooth",
    });
  }, [openIndex]);

  if (!modules.length) return null;

  const onToggle = (idx: number) => {
    setOpenIndex((prev) => (prev === idx ? null : idx));
  };

  return (
    <section className={` ${className}`}>
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-gradient-to-b from-sky-50/70 to-white shadow-sm">
        <div ref={containerRef} className="relative p-2 md:p-3">
          {/* full track */}
          <div
            className="pointer-events-none absolute w-[3px] bg-sky-100"
            style={{
              left: trackLeft,
              top: trackTop,
              bottom: trackBottom,
              zIndex: 0,
              borderRadius: 9999,
            }}
          />
          {/* progress to active dot (never past it) */}
          <div
            className="pointer-events-none absolute w-[3px] bg-gradient-to-b from-sky-500 to-sky-400 transition-all duration-300"
            style={{
              left: trackLeft,
              top: trackTop,
              height: progressHeight,
              zIndex: 1,
              borderRadius: 9999,
              boxShadow:
                openIndex !== null
                  ? "0 0 10px rgba(2,132,199,0.35)"
                  : undefined,
            }}
          />

          <ul className="relative z-10 divide-y divide-slate-200">
            {modules.map((m, idx) => {
              const isOpen = openIndex === idx;
              const completed = openIndex !== null && idx <= openIndex;

              return (
                <li
                  key={idx}
                  ref={(el) => (rowRefs.current[idx] = el)}
                  className="bg-white/40"
                >
                  <div className="flex">
                    {/* dot column */}
                    <div
                      ref={(el) => (dotRefs.current[idx] = el)}
                      className="flex w-10 shrink-0 items-start justify-center pt-4"
                    >
                      <span
                        className={`mt-0.5 inline-block h-3.5 w-3.5 rounded-full ring-2 transition-all duration-300 ${
                          completed
                            ? "bg-sky-600 ring-sky-100"
                            : "bg-white ring-slate-300"
                        } ${isOpen ? "shadow-[0_0_0_6px_rgba(2,132,199,0.16)]" : ""}`}
                        aria-hidden
                      />
                    </div>

                    {/* header */}
                    <button
                      type="button"
                      onClick={() => onToggle(idx)}
                      aria-expanded={isOpen}
                      className="group flex w-full items-start justify-between gap-4 rounded-xl px-3 py-4 text-left transition-colors hover:bg-white/60 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-500/40"
                    >
                      <div>
                        <div className="text-[15px] font-semibold text-slate-900">
                          {m.title}
                          {m.duration && (
                            <span className="ml-2 text-sm font-normal text-slate-600">
                              • {m.duration}
                            </span>
                          )}
                        </div>
                        {m.summary && (
                          <p className="mt-0.5 text-sm text-slate-600">
                            {m.summary}
                          </p>
                        )}
                      </div>
                      <ChevronDown
                        className={`mt-1 h-4 w-4 shrink-0 text-slate-500 transition-transform duration-300 ${
                          isOpen ? "rotate-180" : ""
                        }`}
                      />
                    </button>
                  </div>

                  {/* body */}
                  <div
                    className={`grid overflow-hidden transition-all duration-300 ease-out ${
                      isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                    }`}
                  >
                    <div className="min-h-0">
                      <div className="px-3 pb-4 pl-[3.5rem] text-sm leading-6 text-slate-700">
                        {Array.isArray(m.bullets) && m.bullets.length > 0 && (
                          <ul className="list-disc pl-5">
                            {m.bullets.map((b, i) => (
                              <li key={i} className="mb-1">
                                {b}
                              </li>
                            ))}
                          </ul>
                        )}
                        {m.resources?.length ? (
                          <ul className="mt-3 list-disc pl-5">
                            {m.resources.map((r, i) => (
                              <li key={i}>
                                <a
                                  href={r.href}
                                  className="text-sky-600 underline-offset-2 hover:underline"
                                >
                                  {r.label}
                                </a>
                              </li>
                            ))}
                          </ul>
                        ) : null}
                      </div>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </section>
  );
}
