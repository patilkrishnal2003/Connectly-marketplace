import { cn } from "@/lib/cn";
import { Quote } from "lucide-react";

type Platform = "linkedin" | "google";

export type Testimonial = {
  id: string;
  platform: Platform;
  title: string;
  rating: number;
  snippet: string;
  readMoreUrl: string;
  user: {
    name: string;
    role: string;
    avatar: string;
    profileUrl: string;
  };
};

function Stars({ n }: { n: number }) {
  return (
    <div className="text-amber-400 text-sm" aria-label={`${n} out of 5 stars`}>
      {"★".repeat(n)}
      <span className="text-gray-300">{"★".repeat(5 - n)}</span>
    </div>
  );
}

function LinkedInIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden>
      <path fill="#0A66C2" d="M4.98 3.5C4.98 4.88 3.86 6 2.5 6S0 4.88 0 3.5 1.12 1 2.5 1s2.48 1.12 2.48 2.5zM.5 8h4V24h-4V8zm7.98 0h3.84v2.2h.06c.54-1.02 1.86-2.2 3.83-2.2 4.1 0 4.86 2.7 4.86 6.2V24h-4v-7.3c0-1.74-.03-3.98-2.43-3.98-2.44 0-2.81 1.9-2.81 3.85V24h-4V8z"/>
    </svg>
  );
}
function GoogleIcon() {
  return (
    <svg viewBox="0 0 48 48" className="h-4 w-4" aria-hidden>
      <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.9 31.7 29.4 35 24 35c-6.6 0-12-5.4-12-12s5.4-12 12-12c3 0 5.7 1.1 7.7 3l5.7-5.7C33.9 5 29.2 3 24 3 12.4 3 3 12.4 3 24s9.4 21 21 21c10.5 0 20-7.6 20-21 0-1.3-.1-2.5-.4-3.5z"/>
      <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.5 16.8 18.9 14 24 14c3 0 5.7 1.1 7.7 3l5.7-5.7C33.9 5 29.2 3 24 3 16.4 3 9.7 7.2 6.3 14.7z"/>
      <path fill="#4CAF50" d="M24 45c5.3 0 10.1-1.8 13.8-4.8l-6.4-5.2C29.9 36.6 27.1 38 24 38c-5.4 0-9.9-3.3-11.6-8.1l-6.5 5C9.5 40.4 16.2 45 24 45z"/>
      <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3C34.8 31.7 30.8 35 24 35c-5.4 0-10.2-3.4-11.9-8.1l-6.5 5C8.5 39.4 15.6 45 24 45c10.5 0 20-7.6 20-21 0-1.3-.1-2.5-.4-3.5z"/>
    </svg>
  );
}

export default function TestimonialCard({ t }: { t: Testimonial }) {
  return (
    <div
      className={cn(
        "group relative flex h-full flex-col rounded-2xl border bg-white p-5 shadow-sm",
        "border-slate-200 transition-colors duration-200",
        // SIMPLE hover: only border color changes
        "hover:border-emerald-400"
      )}
    >
{/* Quote badge — smaller, perfectly centered, simple hover */}
<div
  className={cn(
    "pointer-events-none absolute -top-5 left-6 z-20",
    "grid h-10 w-10 place-items-center rounded-full bg-white shadow-sm",
    // keep the circle border constant; mask the card border behind it
    "ring-1 ring-slate-200 ring-offset-2 ring-offset-white"
  )}
  aria-hidden
>
  <Quote
    className="h-4 w-4 text-slate-400 transition-colors duration-200 group-hover:text-emerald-600"
    strokeWidth={2}
  />
</div>



      <h4 className="pr-8 text-[15px] font-semibold text-gray-900">{t.title}</h4>
      <div className="mt-2">
        <Stars n={t.rating} />
      </div>

      <p className="mt-2 line-clamp-4 text-sm text-gray-700">{t.snippet}</p>

      <a href={t.readMoreUrl} className="mt-2 text-sm font-medium text-sky-700 hover:underline">
        Read More
      </a>

      <div className="my-3 h-px w-full bg-gray-100" />

      <div className="mt-auto flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img
            src={t.user.avatar}
            alt=""
            className="h-10 w-10 rounded-full object-cover ring-1 ring-gray-100"
          />
          <div>
            <div className="text-sm font-semibold text-gray-900">{t.user.name}</div>
            <div className="text-xs text-gray-600">{t.user.role}</div>
          </div>
        </div>

        <a
          href={t.user.profileUrl}
          target="_blank"
          rel="noreferrer"
          className="transition-opacity hover:opacity-90"
          aria-label="View profile"
          title="View profile"
        >
          {t.platform === "linkedin" ? <LinkedInIcon /> : <GoogleIcon />}
        </a>
      </div>
    </div>
  );
}
