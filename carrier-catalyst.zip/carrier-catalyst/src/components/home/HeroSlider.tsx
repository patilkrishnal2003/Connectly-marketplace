import { useEffect, useMemo, useState } from "react";
import slidesJson from "@/data/heroSlides.json";
import { Button } from "@/components/ui/button";
import { CheckCircle2 } from "lucide-react";

type Slide = {
  id: string;
  titleLines: string[];
  subtext: string | null;
  bullets: string[];
  image: string; // remote URL or /public path like "/hero/slide1.jpg"
  primaryCta?: { label: string; href: string } | null;
  secondaryCta?: { label: string; href: string } | null;
};

const AUTOPLAY_MS = 6500;

export default function HeroSlider() {
  const slides = useMemo(() => slidesJson as Slide[], []);
  const [idx, setIdx] = useState(0);
  const [paused, setPaused] = useState(false);
  const [loaded, setLoaded] = useState<boolean[]>(
    () => new Array(slides.length).fill(false)
  );

  // Preload images so the first one is ready immediately
  useEffect(() => {
    slides.forEach((s, i) => {
      const img = new Image();
      img.src = s.image;
      img.onload = () =>
        setLoaded((arr) => {
          if (arr[i]) return arr;
          const next = [...arr];
          next[i] = true;
          return next;
        });
    });
  }, [slides]);

  // Autoplay (pause on hover)
  useEffect(() => {
    if (paused || slides.length <= 1) return;
    const t = window.setInterval(() => {
      setIdx((i) => (i + 1) % slides.length);
    }, AUTOPLAY_MS);
    return () => window.clearInterval(t);
  }, [paused, slides.length]);

  const go = (i: number) => setIdx(i);

  return (
    <section
      className="relative w-full overflow-hidden bg-white"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      {/* Full-bleed, responsive height */}
      <div className="relative w-full min-h-[56vh] md:min-h-[64vh] lg:min-h-[72vh]">
        {/* Subtle base placeholder so first render is never blank */}
        <div className="absolute inset-0 z-0 bg-gradient-to-br from-slate-100 to-slate-200" />

        {/* Crossfading background images */}
        <div className="absolute inset-0 z-0">
          {slides.map((s, i) => (
            <img
              key={s.id}
              src={s.image}
              alt=""
              loading={i === 0 ? "eager" : "lazy"}
              onLoad={() =>
                setLoaded((arr) => {
                  if (arr[i]) return arr;
                  const next = [...arr];
                  next[i] = true;
                  return next;
                })
              }
              className={[
                "absolute inset-0 h-full w-full object-cover transition-opacity duration-700 ease-out",
                loaded[i] && i === idx ? "opacity-100" : "opacity-0",
                i === idx ? "kenburns" : ""
              ].join(" ")}
            />
          ))}

          {/* Premium soft gradient for readability */}
          <div className="pointer-events-none absolute inset-0 z-10 bg-gradient-to-r from-white via-white/70 to-white/10 md:from-white md:via-white/60 md:to-transparent" />
        </div>

        {/* Content container */}
        <div className="relative z-20 mx-auto max-w-7xl px-4 py-12 md:py-16 lg:py-20">
          <div className="max-w-2xl">
            <h1 className="text-4xl font-extrabold leading-tight tracking-tight text-gray-900 md:text-6xl">
              {slides[idx].titleLines.map((t, i) => (
                <span key={i} className="block">{t}</span>
              ))}
            </h1>

            {slides[idx].subtext && (
              <p className="mt-4 text-base text-gray-600 md:text-lg">
                {slides[idx].subtext}
              </p>
            )}

            {!!slides[idx].bullets.length && (
              <ul className="mt-6 space-y-3">
                {slides[idx].bullets.map((b) => (
                  <li key={b} className="flex items-center gap-2 text-gray-800">
                    <CheckCircle2 className="h-5 w-5" />
                    <span>{b}</span>
                  </li>
                ))}
              </ul>
            )}

            <div className="mt-8 flex flex-wrap items-center gap-3">
              {slides[idx].primaryCta && (
                <Button
                  className="rounded-md bg-sky-600 px-5 text-white shadow-sm hover:bg-sky-700"
                  onClick={() => (window.location.href = slides[idx].primaryCta!.href)}
                >
                  {slides[idx].primaryCta!.label}
                </Button>
              )}
              {slides[idx].secondaryCta && (
                <Button
                  variant="outline"
                  className="rounded-md"
                  onClick={() => (window.location.href = slides[idx].secondaryCta!.href)}
                >
                  {slides[idx].secondaryCta!.label}
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Dots only (classy pill style) */}
        <div className="absolute bottom-5 left-1/2 z-30 flex -translate-x-1/2 items-center gap-2 rounded-full bg-white/70 px-2 py-1 shadow backdrop-blur">
          {slides.map((s, i) => (
            <button
              key={s.id}
              aria-label={`Go to slide ${i + 1}`}
              onClick={() => go(i)}
              className={`h-2.5 w-2.5 rounded-full transition-all ${
                i === idx
                  ? "w-5 bg-sky-600"
                  : "bg-gray-300 hover:bg-gray-400"
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
