import CoursePill from "../home/CoursePill";
import data from "@/data/domains.json";

/** Single marquee row that loops seamlessly */
function MarqueeRow({
  items,
  duration = 36,     // seconds for one cycle
  direction = "right" as "right" | "left",
}: {
  items: { id: string; title: string; emoji: string }[];
  duration?: number;
  direction?: "right" | "left";
}) {
  // We duplicate items once so we can translate by -50% and loop seamlessly
  const doubled = [...items, ...items];

  return (
    <div
      className={`marquee ${direction === "right" ? "marquee--right" : "marquee--left"}`}
      style={{ ["--duration" as any]: `${duration}s` }}
    >
      <div className="marquee__track">
        {doubled.map((it, idx) => (
          <CoursePill key={`${it.id}-${idx}`} emoji={it.emoji} title={it.title} />
        ))}
      </div>
    </div>
  );
}

export default function ScrollingDomains() {
  // split the list for two rows (roughly half/half)
  const mid = Math.ceil(data.length / 2);
  const row1 = data.slice(0, mid);
  const row2 = data.slice(mid);

  return (
    <section className="mx-auto my-16 max-w-6xl px-4">
      {/* rounded light section wrapper */}
      <div className="rounded-[28px] bg-gray-50 p-6 sm:p-8 lg:p-10 shadow-[inset_0_1px_0_rgba(0,0,0,0.04)]">
        <div className="text-center">
          <div className="text-[11px] font-semibold tracking-widest text-sky-600">
            HIGH-IMPACT SKILLS FOR THE FUTURE OF WORK
          </div>
          <h2 className="mt-2 text-2xl font-black text-gray-900 sm:text-3xl">
            Choose From 25+ In-Demand Domains
          </h2>
          <p className="mx-auto mt-2 max-w-3xl text-sm text-gray-600">
            Explore immersive programs in AI, Data, Cloud, DevOps, Web Development, Cybersecurity,
            and more. Learn job-ready skills taught by experts.
          </p>
        </div>

        {/* Rows – both move to the RIGHT, different speeds for a premium feel */}
        <div className="mt-6 space-y-4">
          <MarqueeRow items={row1} duration={40} direction="right" />
          <MarqueeRow items={row2} duration={40} direction="left" />
        </div>

        <div className="mt-8 flex justify-center">
          <a
            href="#"
            className="inline-flex items-center rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-rose-700"
          >
            Explore All Courses
          </a>
        </div>
      </div>
    </section>
  );
}
