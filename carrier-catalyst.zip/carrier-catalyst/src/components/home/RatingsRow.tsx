import { Star } from "lucide-react";
import { cn } from "@/lib/cn";

// Brand marks kept inline so you don't depend on external assets
function GoogleGlyph() {
  return (
    <svg viewBox="0 0 48 48" className="h-5 w-5" aria-hidden>
      <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.9 31.7 29.4 35 24 35c-6.6 0-12-5.4-12-12s5.4-12 12-12c3 0 5.7 1.1 7.7 3l5.7-5.7C33.9 5 29.2 3 24 3 12.4 3 3 12.4 3 24s9.4 21 21 21c10.5 0 20-7.6 20-21 0-1.3-.1-2.5-.4-3.5z"/>
      <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.5 16.8 18.9 14 24 14c3 0 5.7 1.1 7.7 3l5.7-5.7C33.9 5 29.2 3 24 3 16.4 3 9.7 7.2 6.3 14.7z"/>
      <path fill="#4CAF50" d="M24 45c5.3 0 10.1-1.8 13.8-4.8l-6.4-5.2C29.9 36.6 27.1 38 24 38c-5.4 0-9.9-3.3-11.6-8.1l-6.5 5C9.5 40.4 16.2 45 24 45z"/>
      <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3C34.8 31.7 30.8 35 24 35c-5.4 0-10.2-3.4-11.9-8.1l-6.5 5C8.5 39.4 15.6 45 24 45c10.5 0 20-7.6 20-21 0-1.3-.1-2.5-.4-3.5z"/>
    </svg>
  );
}
function FacebookGlyph() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" aria-hidden>
      <path fill="#1877F2" d="M24 12.073C24 5.405 18.627 0 12 0S0 5.405 0 12.073C0 18.1 4.388 23.093 10.125 24v-8.437H7.078v-3.49h3.047V9.356c0-3.02 1.792-4.687 4.533-4.687 1.313 0 2.686.235 2.686.235v2.953h-1.515c-1.494 0-1.959.93-1.959 1.887v2.266h3.328l-.532 3.49h-2.796V24C19.612 23.093 24 18.1 24 12.073z"/>
    </svg>
  );
}
function SwitchUpGlyph() {
  return (
    <div className="grid h-5 w-5 place-items-center rounded-full bg-[#E2463C] text-[12px] font-semibold leading-none text-white">
      s
    </div>
  );
}
function CourseReportGlyph() {
  return (
    <div className="grid h-5 w-5 place-items-center rounded-[6px] bg-[#3FAE2A] text-[10px] font-bold leading-none text-white">
      CR
    </div>
  );
}

type Brand = "google" | "facebook" | "switchup" | "coursereport";
type RatingItem = {
  id: string;
  label: string;
  score: number;
  reviews: number;
  brand: Brand;
  url?: string;
};

const ITEMS: RatingItem[] = [
  { id: "google",       label: "Google",        score: 4.8, reviews: 6933, brand: "google",       url: "#" },
  { id: "facebook",     label: "Facebook",      score: 4.7, reviews: 1212, brand: "facebook",     url: "#" },
  { id: "switchup",     label: "Switchup",      score: 4.9, reviews: 209,  brand: "switchup",     url: "#" },
  { id: "coursereport", label: "Course Report", score: 4.8, reviews: 403,  brand: "coursereport", url: "#" },
];

function BrandIcon({ brand }: { brand: Brand }) {
  switch (brand) {
    case "google": return <GoogleGlyph />;
    case "facebook": return <FacebookGlyph />;
    case "switchup": return <SwitchUpGlyph />;
    case "coursereport": return <CourseReportGlyph />;
  }
}
function brandTextClass(brand: Brand) {
  if (brand === "facebook") return "text-[#1877F2]";
  if (brand === "coursereport") return "text-[#2FA31E]";
  return "text-slate-900";
}
function format(n: number) {
  return n.toLocaleString();
}

function RatingTile({ item }: { item: RatingItem }) {
  return (
    <a
      href={item.url}
      className={cn(
        "group block rounded-xl ring-1 ring-slate-200/60 bg-white/80",
        "px-4 py-3 md:px-4 md:py-4",
        "transition-all duration-200 hover:bg-white hover:-translate-y-0.5 hover:shadow-sm hover:ring-slate-300",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-300"
      )}
      aria-label={`${item.label} ${item.score.toFixed(1)} out of 5 — ${format(item.reviews)} reviews`}
    >
      {/* top row: brand + rating */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <BrandIcon brand={item.brand} />
          <span className={cn("text-sm font-semibold tracking-tight", brandTextClass(item.brand))}>
            {item.label}
          </span>
        </div>

        <div className="flex items-center gap-1 text-slate-900">
          <Star className="mr-1 h-4 w-4 fill-amber-400 stroke-amber-400" />
          <span className="text-sm font-semibold">{item.score.toFixed(1)}</span>
          <span className="text-xs text-slate-400">/5</span>
        </div>
      </div>

      {/* bottom row: reviews */}
      <div className="mt-1 text-xs text-slate-500">
        <span className="font-medium text-slate-700">{format(item.reviews)}</span>{" "}
        <span className="text-slate-400">Reviews</span>
      </div>
    </a>
  );
}

export default function RatingsRow() {
  return (
    <section className="mx-auto mt-8 w-full max-w-6xl px-4">
      <div
        className={cn(
          "rounded-3xl bg-white/90 backdrop-blur",
          "ring-1 ring-slate-200 shadow-[0_10px_30px_rgba(2,6,23,0.06)]",
          "px-4 py-4 md:px-6 md:py-6"
        )}
      >
        <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {ITEMS.map((it) => (
            <li key={it.id} className="min-h-[74px]">
              <RatingTile item={it} />
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
