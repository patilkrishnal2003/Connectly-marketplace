type Props = {
  emoji: string;
  title: string;
  href?: string;
};

export default function CoursePill({ emoji, title, href = "#" }: Props) {
  return (
    <a
      href={href}
      className="group inline-flex items-center gap-3 rounded-2xl border border-gray-200 bg-white px-4 py-3 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
    >
      <span className="grid h-9 w-9 place-items-center rounded-xl bg-gray-50 text-lg">{emoji}</span>
      <div className="min-w-0">
        <div className="truncate text-sm font-semibold text-gray-900">{title}</div>
        <div className="text-[11px] text-gray-500">
          Explore <span aria-hidden>↗</span>
        </div>
      </div>
    </a>
  );
}
