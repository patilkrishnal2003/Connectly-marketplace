import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";
import cards from "@/data/testimonials.json";
import TestimonialCard, { type Testimonial } from "./TestimonialCard";
import { cn } from "@/lib/cn";
import RatingsRow from "@/components/home/RatingsRow";

type Filter = "all" | "linkedin" | "google";

function useVisibleCount() {
  const [count, setCount] = useState(3);
  useEffect(() => {
    const calc = () => {
      const w = window.innerWidth;
      setCount(w >= 1024 ? 3 : w >= 640 ? 2 : 1);
    };
    calc();
    window.addEventListener("resize", calc);
    return () => window.removeEventListener("resize", calc);
  }, []);
  return count;
}

export default function TestimonialsSection() {
  const [filter, setFilter] = useState<Filter>("all");
  const all = cards as Testimonial[];
  const filtered = useMemo(
    () => (filter === "all" ? all : all.filter((t) => t.platform === filter)),
    [filter, all]
  );

  const visible = useVisibleCount();
  const [idx, setIdx] = useState(0);
  const n = filtered.length;

  // wrap helpers
  const wrap = (i: number) => (n === 0 ? 0 : (i + n) % n);
  const next = () => setIdx((i) => wrap(i + 1));
  const prev = () => setIdx((i) => wrap(i - 1));

  // compute current page items (wrap-around)
  const page = Array.from({ length: Math.min(visible, n) }, (_, k) => filtered[wrap(idx + k)]);
  const centerRel = Math.floor(page.length / 2);

  return (
    <section className="mx-auto my-20 max-w-6xl px-4">
      <div className="rounded-[28px] bg-gray-50 p-6 sm:p-8">
        <div className="text-center">
          <div className="text-[11px] font-semibold tracking-widest text-sky-600">
            LEARNER REVIEWS FROM THE WORLD OVER
          </div>
          <h2 className="mt-2 text-2xl font-black text-gray-900 sm:text-3xl">
            Testimonials That Speak Volumes
          </h2>

          {/* filter pills */}
          <div className="mt-4 inline-flex rounded-full border bg-white p-1 shadow-sm">
            {[
              { v: "all", label: "All Reviews" },
              { v: "linkedin", label: "LinkedIn" },
              { v: "google", label: "Google" }
            ].map((opt) => (
              <button
                key={opt.v}
                onClick={() => setFilter(opt.v as Filter)}
                className={cn(
                  "px-4 py-2 text-sm rounded-full",
                  filter === (opt.v as Filter)
                    ? "bg-gray-900 text-white"
                    : "text-gray-700 hover:bg-gray-100"
                )}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* carousel */}
        <div className="relative mt-8">
          <div className="pt-4 overflow-visible">
            <AnimatePresence initial={false} mode="wait">
              <motion.div
                key={`${filter}-${idx}-${visible}`}
                initial={{ x: 30, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: -30, opacity: 0 }}
                transition={{ duration: 0.25, ease: "easeOut" }}
                className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3"
              >
                {page.map((t, i) => (
                  <TestimonialCard key={t.id} t={t} highlight={i === centerRel} />
                ))}
              </motion.div>
            </AnimatePresence>
          </div>

          {/* arrows */}
          <div className="mt-4 flex justify-center gap-3">
            <button
              onClick={prev}
              className="grid h-9 w-9 place-items-center rounded-full border bg-white shadow hover:bg-gray-50"
              aria-label="Previous"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button
              onClick={next}
              className="grid h-9 w-9 place-items-center rounded-full border bg-white shadow hover:bg-gray-50"
              aria-label="Next"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* ratings row */}
           <RatingsRow />     
      </div>
    </section>
  );
}
