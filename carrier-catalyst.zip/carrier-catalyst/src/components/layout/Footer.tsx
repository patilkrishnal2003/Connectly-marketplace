import {
  Mail,
  Phone,
  MapPin,
  Clock,
  Twitter,
  Linkedin,
  Facebook,
  Youtube,
  Send,
} from "lucide-react";

export default function Footer() {
  const year = new Date().getFullYear();

  function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const email = new FormData(e.currentTarget).get("email");
    alert(`Thanks! We'll keep you posted, ${email}`);
    e.currentTarget.reset();
  }

  return (
    <footer className="mt-16 border-t border-slate-200/70 bg-white">
      {/* subtle brand accent */}
      {/* <div className="h-0.5 w-full bg-gradient-to-r from-emerald-400 via-sky-400 to-fuchsia-500" /> */}

      <div className="mx-auto max-w-7xl px-6 py-12 sm:py-16">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-5">
          {/* Brand + newsletter + socials */}
          <div className="sm:col-span-2">
            <div className="flex items-center gap-2">
                <span className="text-[22px] font-extrabold tracking-tight leading-none">
                <span className="bg-gradient-to-r from-sky-500 via-indigo-500 to-blue-700 bg-clip-text text-transparent">
                    Carrier
                </span>{" "}
                <span className="text-slate-900">Catalyst</span>
                </span>
            </div>

            <p className="mt-4 text-sm leading-6 text-slate-600">
              Learn in-demand skills, earn industry-recognized certifications and
              move faster in your career.
            </p>

            <form onSubmit={onSubmit} className="mt-5 flex max-w-md gap-2">
              <input
                name="email"
                type="email"
                required
                placeholder="Your email address"
                className="w-full rounded-xl border border-slate-300/80 bg-white px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 shadow-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-200"
              />
              <button
                type="submit"
                className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-300"
              >
                <Send className="h-4 w-4" />
                Subscribe
              </button>
            </form>

            <div className="mt-6 flex items-center gap-4">
              <a
                href="#"
                aria-label="LinkedIn"
                className="rounded-lg border border-slate-200 p-2 text-slate-500 hover:border-emerald-200 hover:text-emerald-600"
              >
                <Linkedin className="h-4 w-4" />
              </a>
              <a
                href="#"
                aria-label="Twitter"
                className="rounded-lg border border-slate-200 p-2 text-slate-500 hover:border-emerald-200 hover:text-emerald-600"
              >
                <Twitter className="h-4 w-4" />
              </a>
              <a
                href="#"
                aria-label="Facebook"
                className="rounded-lg border border-slate-200 p-2 text-slate-500 hover:border-emerald-200 hover:text-emerald-600"
              >
                <Facebook className="h-4 w-4" />
              </a>
              <a
                href="#"
                aria-label="YouTube"
                className="rounded-lg border border-slate-200 p-2 text-slate-500 hover:border-emerald-200 hover:text-emerald-600"
              >
                <Youtube className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-sm font-semibold text-slate-900">Company</h4>
            <ul className="mt-4 space-y-2 text-sm text-slate-600">
              <li><a className="hover:text-emerald-700" href="#">About</a></li>
              <li><a className="hover:text-emerald-700" href="#">Careers</a></li>
              <li><a className="hover:text-emerald-700" href="#">Blog</a></li>
              <li><a className="hover:text-emerald-700" href="#">Press</a></li>
            </ul>
          </div>

          {/* Programs */}
          <div>
            <h4 className="text-sm font-semibold text-slate-900">Programs</h4>
            <ul className="mt-4 space-y-2 text-sm text-slate-600">
              <li><a className="hover:text-emerald-700" href="#">Agile Management</a></li>
              <li><a className="hover:text-emerald-700" href="#">Project Management</a></li>
              <li><a className="hover:text-emerald-700" href="#">Data Science</a></li>
              <li><a className="hover:text-emerald-700" href="#">Cloud &amp; DevOps</a></li>
              <li><a className="hover:text-emerald-700" href="#">IT Security</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-sm font-semibold text-slate-900">Contact</h4>
            <ul className="mt-4 space-y-3 text-sm text-slate-600">
              <li className="flex items-start gap-2">
                <MapPin className="mt-0.5 h-4 w-4 text-emerald-600" />
                <span>201, Orbit Plaza, MG Road, Pune 411001, IN</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-emerald-600" />
                <a className="hover:text-emerald-700" href="mailto:hello@carriercatalyst.io">
                  hello@carriercatalyst.io
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-emerald-600" />
                <a className="hover:text-emerald-700" href="tel:+919876543210">
                  +91 98765 43210
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-emerald-600" />
                <span>Mon–Fri • 9:00–18:00 IST</span>
              </li>
            </ul>
          </div>
        </div>

        {/* legal bar */}
        <div className="mt-10 border-t border-slate-200/70 pt-6 text-sm">
          <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
            <p className="text-slate-500">
              © {year} Carrier Catalyst. All rights reserved.
            </p>
            <nav className="flex flex-wrap items-center gap-x-6 gap-y-2 text-slate-600">
              <a className="hover:text-emerald-700" href="#">Terms</a>
              <a className="hover:text-emerald-700" href="#">Privacy</a>
              <a className="hover:text-emerald-700" href="#">Refund Policy</a>
              <a className="hover:text-emerald-700" href="#">Support</a>
            </nav>
          </div>
        </div>
      </div>
    </footer>
  );
}
