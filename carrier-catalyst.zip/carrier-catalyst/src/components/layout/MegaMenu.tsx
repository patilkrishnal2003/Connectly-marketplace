// src/components/marketing/MegaMenu.tsx
import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { cn } from "@/lib/cn";
import {
  categorySlugById,
  categoryPath,
  coursePath,
  courseSlugFrom,
} from "@/lib/paths";
import type { Category, Course } from "@/types";

type Props = {
  open: boolean;
  categories: Category[];
  courses: Course[];         // << using courses, not certificates
  onClose?: () => void;
};

export default function MegaMenu({ open, categories, courses, onClose }: Props) {
  const catList = useMemo(() => categories.filter((c) => c.id !== "all"), [categories]);
  const [active, setActive] = useState<string>(catList[0]?.id ?? "");

  useEffect(() => {
    if (!catList.find((c) => c.id === active)) setActive(catList[0]?.id ?? "");
  }, [catList, active]);

  const activeCat = useMemo(() => catList.find((c) => c.id === active), [active, catList]);
  const activeName = activeCat?.name ?? "";
  const activeSlug = activeCat?.slug ?? "";

  // Right-panel items = COURSES in the active category
  const items = useMemo(
    () => courses.filter((c) => Array.isArray(c.categories) && c.categories.includes(active)),
    [active, courses]
  );

  // Close on Escape
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose?.();
    };
    if (open) window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.18, ease: "easeOut" }}
        >
          <div className="mx-auto max-w-[1200px] px-4">
            {/* Close when pointer leaves the panel area */}
            <div
              className="max-h-[76vh] overflow-hidden rounded-2xl border border-black/5 bg-white/95 text-gray-900 shadow-[0_20px_60px_rgba(0,0,0,0.12)] backdrop-blur-xl supports-[backdrop-filter]:bg-white/92"
              onMouseLeave={() => onClose?.()}
            >
              <div className="grid md:grid-cols-12">
                {/* LEFT sidenav */}
                <aside className="md:col-span-3 lg:col-span-4 border-b bg-white/90 md:border-b-0 md:border-r">
                  <div className="sticky top-0 z-10 border-b bg-white/95 px-3 py-2">
                    <div className="text-xs font-semibold uppercase tracking-wide text-gray-600">
                      Categories
                    </div>
                  </div>

                  <nav className="max-h-[70vh] overflow-y-auto p-2 pr-1">
                    {catList.map((c) => {
                      const selected = c.id === active;
                      return (
                        <Link
                          key={c.id}
                          to={categoryPath(c.slug)}
                          onMouseEnter={() => setActive(c.id)}
                          onFocus={() => setActive(c.id)}
                          onClick={() => onClose?.()}
                          aria-selected={selected}
                          className={cn(
                            "group relative flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm transition",
                            selected
                              ? "bg-sky-50 text-sky-900 ring-1 ring-sky-200"
                              : "text-gray-800 hover:bg-gray-50"
                          )}
                        >
                          <span className="truncate">{c.name}</span>
                          {selected && <span className="h-2 w-2 shrink-0 rounded-full bg-sky-500" />}
                          {selected && (
                            <span className="absolute right-0 top-0 h-full w-1 rounded-l bg-sky-500" />
                          )}
                        </Link>
                      );
                    })}
                  </nav>
                </aside>

                {/* RIGHT content */}
                <section className="md:col-span-9 lg:col-span-8">
                  <div className="sticky top-0 z-10 border-b bg-white/95 px-4 py-3 md:px-6">
                    <div className="flex items-baseline justify-between">
                      <div>
                        <h3 className="text-sm font-semibold">Courses</h3>
                        <p className="text-xs text-gray-600">
                          Hand-picked courses for <span className="font-medium">{activeName}</span>
                        </p>
                      </div>
                      {activeSlug && (
                        <Link
                          to={categoryPath(activeSlug)}
                          onClick={() => onClose?.()}
                          className="hidden rounded-full border px-3 py-1.5 text-sm text-gray-800 hover:bg-gray-50 md:inline-flex"
                        >
                          Explore all courses ↗
                        </Link>
                      )}
                    </div>
                  </div>

                  <div className="max-h-[70vh] overflow-y-auto p-4 pt-4 md:p-6">
                    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                      {items.map((it) => {
                        const chosenCatId = it.categories.includes(active) ? active : it.categories[0];
                        const catSlug = categorySlugById(chosenCatId);
                        const slug = courseSlugFrom(it); // ✅ safe (polymorphic)

                        return (
                          <Link
                            key={it.id}
                            to={coursePath(catSlug, slug)}
                            onClick={() => onClose?.()}
                            className="group overflow-hidden rounded-2xl border bg-white shadow-sm transition hover:shadow-lg"
                          >
                            <div className="relative h-32 w-full overflow-hidden">
                              <img
                                src={it.image}
                                alt={it.title}
                                loading="lazy"
                                className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.05]"
                              />
                              <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
                              {it.badges?.[0] && (
                                <span className="absolute left-3 top-3 rounded-md bg-indigo-600 px-2 py-0.5 text-[11px] font-semibold text-white">
                                  {it.badges[0]}
                                </span>
                              )}
                            </div>
                            <div className="p-3">
                              <div className="line-clamp-2 text-[15px] font-semibold">{it.title}</div>
                              {"hours" in it && typeof it.hours === "number" && (
                                <div className="mt-1 text-xs text-gray-600">{it.hours} Hrs</div>
                              )}
                            </div>
                          </Link>
                        );
                      })}
                    </div>

                    {activeSlug && (
                      <div className="mt-4 flex justify-end md:hidden">
                        <Link
                          to={categoryPath(activeSlug)}
                          onClick={() => onClose?.()}
                          className="inline-flex items-center gap-1 rounded-full border px-3 py-1.5 text-sm text-gray-800 hover:bg-gray-50"
                        >
                          Explore all courses ↗
                        </Link>
                      </div>
                    )}
                  </div>
                </section>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
