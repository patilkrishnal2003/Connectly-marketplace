import { useRef, useState, useEffect } from "react";
import { Grid2x2, Search, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "react-router-dom";
import MegaMenu from "./MegaMenu";
import type { Course } from "@/types";
import categories from "@/data/categories.json";
import courses from "@/data/courses.json";

export default function NavBar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [megaOpen, setMegaOpen] = useState(false);
  const timer = useRef<number | null>(null);

  // Close mega menu after any route change
  const location = useLocation();
  useEffect(() => {
    setMegaOpen(false);
  }, [location.pathname]);

  const openNow = () => {
    if (timer.current) window.clearTimeout(timer.current);
    setMegaOpen(true);
  };
  const closeSoon = (ms = 80) => {
    if (timer.current) window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setMegaOpen(false), ms);
  };

  return (
    <>
      {/* Header is the anchor for the full-width panel */}
      <header
        className="relative sticky top-0 z-50 w-full border-b bg-white/70 backdrop-blur supports-[backdrop-filter]:bg-white/60"
        onMouseLeave={() => closeSoon(80)}
      >
        <div className="mx-auto max-w-6xl px-4">
          <nav className="flex items-center justify-between gap-3 py-3">
            {/* Brand */}
            <a href="/" className="flex items-center gap-2">
              <span className="text-2xl font-black tracking-tight">
                <span className="bg-gradient-to-r from-sky-600 to-indigo-600 bg-clip-text text-transparent">
                  Carrier
                </span>{" "}
                <span className="text-gray-900">Catalyst</span>
              </span>
            </a>

            {/* Center (desktop) */}
            <div className="hidden flex-1 items-center gap-3 md:flex">
              <Button
                onMouseEnter={openNow}
                onClick={() => setMegaOpen((v) => !v)}
                className="inline-flex items-center gap-2 whitespace-nowrap rounded-full bg-sky-600 px-4 py-2 shadow-sm hover:bg-sky-700"
              >
                <Grid2x2 className="h-4 w-4" />
                <span className="font-semibold">All Courses</span>
              </Button>

              {/* Search */}
              <div className="relative w-full max-w-lg">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                <input
                  className="w-full rounded-full border bg-white pl-9 pr-3 py-2 text-sm text-gray-900 placeholder:text-gray-500 outline-none focus:ring-2 focus:ring-sky-600/30"
                  placeholder="What do you want to learn?"
                />
              </div>
            </div>

            {/* Right (desktop) — login removed */}
            <div className="hidden items-center gap-4 md:flex">
              <a className="text-sm text-gray-800 hover:text-gray-900" href="#">
                For Business
              </a>
              <a className="text-sm text-gray-800 hover:text-gray-900" href="#">
                Resources
              </a>
            </div>

            {/* Mobile */}
            <button
              className="p-2 md:hidden"
              onClick={() => setMobileOpen((v) => !v)}
              aria-label="Toggle menu"
            >
              {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </nav>
        </div>

        {/* Mega menu panel */}
        <div className="absolute left-0 right-0 top-full -mt-px">
          {/* close on any internal click is handled via onClose */}
          <MegaMenu
            open={megaOpen}
            categories={categories as any}
            courses={courses as Course[]}
            onClose={() => setMegaOpen(false)}
          />
        </div>
      </header>

      {/* Backdrop (click closes) */}
      <AnimatePresence>
        {megaOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="fixed inset-0 z-40 bg-black/45 backdrop-blur-[2px]"
            onClick={() => setMegaOpen(false)}
          />
        )}
      </AnimatePresence>
    </>
  );
}
