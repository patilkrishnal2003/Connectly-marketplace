// ---------- Course types ----------

export interface CourseFAQItem {
  /** The question text */
  question: string;
  /** Either a paragraph or bullet points */
  answer: string | string[];
  /** Optional related links shown under the answer */
  links?: { label: string; href: string }[];
}

export interface CourseLearningModule {
  id?: string;
  title: string;
  /** Short line shown under title when collapsed */
  summary?: string;
  /** Bullet points shown when expanded */
  bullets?: string[];
  /** e.g. "2 hrs" */
  duration?: string;
  /** Optional links within the module */
  resources?: { label: string; href: string }[];
}

export interface CourseLearningPath {
  /** Heading for the section (defaults to "Learning Path") */
  title?: string;
  modules: CourseLearningModule[];
}

/** Learning objectives (cards) */
export interface CourseObjectiveItem {
  title: string;
  description?: string;
}
export interface CourseObjectives {
  eyebrow?: string;
  title?: string;
  items: CourseObjectiveItem[];
}

export interface Course {
  id: string;
  title: string;
  image: string;
  /** Category IDs this course belongs to, e.g. ["pm", "agile"] */
  categories: string[];

  // ---------- List / card fields you already use ----------
  modes?: string[];
  hours?: number;
  enrolled?: number;
  priceInr?: number;
  badges?: string[];
  tag?: string;            // "Trending" | "Recommended" etc.
  duration?: string;       // e.g. "16 Hrs" (can be derived from hours)
  slug?: string;           // slug for URL (fallback derived from title)

  // ---------- Course Hero (used by CourseHero component) ----------
  hero?: {
    /** Small pill above title, e.g. "Recommended" / "Certification Program" */
    label?: string;
    /** Big headline; defaults to course.title */
    title?: string;
    /** Short supporting paragraph */
    subtitle?: string;
    /** Up to 4-5 bullets shown with check icons */
    bullets?: string[];
    /** Hero image; defaults to course.image */
    image?: string;
    /** Main CTA text (defaults: "Enroll now") */
    ctaPrimaryText?: string;
    /** Secondary CTA text (defaults: "Download syllabus") */
    ctaSecondaryText?: string;
    /** Optional link for the secondary CTA (e.g., syllabus PDF) */
    ctaSecondaryHref?: string;
  };

  // ---------- Info rail (under hero on course detail) ----------
  /** ISO date like "2025-08-25" */
  applicationCloseOn?: string;
  /** Prefer this for rail if you want a custom label, e.g. "11 Months" */
  durationLabel?: string;
  /** e.g. "Live, Online, Interactive" */
  learningFormat?: string;

  // ---------- Course-specific FAQs on the detail page ----------
  faqs?: CourseFAQItem[];

  // ---------- Learning path (timeline accordion) ----------
  learningPath?: CourseLearningPath;

  // ---------- Learning objectives (cards) ----------
  objectives?: CourseObjectives;

  // ---------- Future sections ----------
  skillsCovered?: string[];
  keyFeatures?: string[];
  whyJoin?: string[];
  /** PDF or external link */
  syllabusUrl?: string;
}
