// src/types/category.ts

/** ---------- FAQ ---------- */
export interface CategoryFAQLink {
  label: string;
  href: string;
}

export interface CategoryFAQItem {
  /** The question text */
  question: string;
  /** A paragraph string or an array of bullet lines */
  answer: string | string[];
  /** Optional deep-links shown as bullets under the answer */
  links?: CategoryFAQLink[];
}

/** ---------- Insights / Industry Trends ---------- */
export interface CategoryInsightCard {
  /**
   * Icon key used by the UI component.
   * Supported: "wallet" | "gem" | "smartphone" | "radio" | "globe" | "growth"
   */
  icon?: string;
  /** Big figure (e.g., "60%", "$90K") */
  value: string;
  /** Small caption below the value */
  caption: string;
}

export interface CategoryInsights {
  /** Small eyebrow text, e.g., "DEMAND FOR ..." */
  eyebrow?: string;
  /** Section title */
  title: string;
  /** Left-column paragraphs */
  body?: string[];
  /** Stat cards grid */
  cards: CategoryInsightCard[];
}

/** ---------- Category ---------- */
export interface Category {
  id: string;            // "pm"
  name: string;          // "Project Management"
  slug: string;          // "project-management"

  // Optional hero section for category pages
  hero?: {
    label?: string;
    title?: string;
    subtitle?: string;
    bullets?: string[];
    image?: string;
    ctaExploreText?: string;
    ctaAdvisorText?: string;
  };

  /** Optional FAQs for the category page */
  faqs?: CategoryFAQItem[];

  /** Optional Industry Trends / Insights section */
  insights?: CategoryInsights;
}
