import { Outlet } from "react-router-dom";
import NavBar from "@/components/layout/NavBar";     // you already have this
import Footer from "@/components/layout/Footer";        // you already have this

export default function SiteLayout() {
  return (
    <main className="min-h-dvh bg-gray-50">
      <NavBar />
      <Outlet />          {/* each page renders here */}
      <Footer />
    </main>
  );
}
