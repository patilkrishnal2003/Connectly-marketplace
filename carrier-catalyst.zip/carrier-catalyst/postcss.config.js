// postcss.config.js
export default {
  plugins: {
    "@tailwindcss/postcss": {},   // <— use this for Tailwind v4
    autoprefixer: {},
  },
};
